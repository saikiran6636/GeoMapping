import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap, map } from 'rxjs';

export interface User {
  id?: number;
  username?: string;
  name?: string;
  email?: string;
  phoneNumber?: string;
  password?: string;
  role: 'ADMIN' | 'ORGANIZER' | 'MEMBER';
  locationLat?: number;
  locationLng?: number;
  rewardPoints?: number;
}

export interface Project {
  id?: number;
  name: string;
  description: string;
  location?: string;
  latitude: number;
  longitude: number;
  organizerId?: number;
  organizerName?: string;
  rewardPoints?: number;
  status?: 'PENDING' | 'APPROVED' | 'REJECTED';
  startDate?: string;
  endDate?: string;
  imageUrl?: string;
}

export interface Enrollment {
  id?: number;
  memberId: number;
  projectId: number;
  pointsEarned: number;
  enrolledAt?: string;
  completionDate?: string;
  status?: string;
  evidenceUrl?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8988/api';
  private userSubject = new BehaviorSubject<User | null>(this.getUserFromStorage());
  public user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient) { }

  private getUserFromStorage(): User | null {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  }

  // Auth
  login(email: string, password: string, role: string): Observable<User> {
    return this.http.post<any>(`${this.apiUrl}/auth/login`, { email, password, role }).pipe(
      tap(user => {
        localStorage.setItem('user', JSON.stringify(user));
        this.userSubject.next(user);
      })
    );
  }

  register(user: User): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/auth/register`, user);
  }

  checkEmailExists(email: string, role: string): Observable<{ exists: boolean }> {
    return this.http.post<{ exists: boolean }>(`${this.apiUrl}/auth/check-email`, { email, role });
  }

  logout() {
    localStorage.removeItem('user');
    this.userSubject.next(null);
  }

  getCurrentUser(): User | null {
    return this.userSubject.value;
  }

  refreshUser() {
    const user = this.getUserFromStorage();
    this.userSubject.next(user);
  }

  updateUser(updatedFields: Partial<User>) {
    const currentUser = this.getCurrentUser();
    if (currentUser) {
      const newUser = { ...currentUser, ...updatedFields };
      localStorage.setItem('user', JSON.stringify(newUser));
      this.userSubject.next(newUser);
    }
  }

  // Projects
  requestProject(project: Project): Observable<Project> {
    return this.http.post<Project>(`${this.apiUrl}/projects/request`, project);
  }

  getPendingProjects(): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.apiUrl}/projects/pending`);
  }

  getPublicProjects(): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.apiUrl}/projects/public`);
  }

  getOrganizerProjects(organizerId: number): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.apiUrl}/projects/organizer/${organizerId}`);
  }

  updateProjectStatus(id: number, status: string): Observable<Project> {
    return this.http.post<Project>(`${this.apiUrl}/projects/${id}/status`, { status });
  }

  enrollInProject(projectId: number, memberId: number): Observable<Enrollment> {
    return this.http.post<Enrollment>(`${this.apiUrl}/projects/${projectId}/enroll/${memberId}`, {});
  }

  getMemberEnrollments(memberId: number): Observable<Enrollment[]> {
    return this.http.get<Enrollment[]>(`${this.apiUrl}/projects/enrollments/${memberId}`);
  }

  getMemberFullDetails(memberId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/projects/member/${memberId}`).pipe(
      map(data => {
        // Flatten the multi-table response for the frontend
        if (data.user && data.profile) {
          const flatUser = {
            ...data.user,
            locationLat: data.profile.locationLat,
            locationLng: data.profile.locationLng,
            rewardPoints: data.profile.rewardPoints
          };
          this.updateUser(flatUser); // Update local state with fresh DB data
          return flatUser;
        }
        return data.user || data;
      })
    );
  }
  getProjectMembers(projectId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/projects/${projectId}/members`);
  }

  updateProject(projectId: number, project: Project): Observable<Project> {
    return this.http.put<Project>(`${this.apiUrl}/projects/${projectId}`, project);
  }

  deleteProject(projectId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/projects/${projectId}`);
  }

  getMemberRewards(memberId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/projects/rewards/${memberId}`);
  }

  updateProfile(userId: number, profileData: any): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/auth/profile/${userId}`, profileData).pipe(
      tap(updatedUser => {
        localStorage.setItem('user', JSON.stringify(updatedUser));
        this.userSubject.next(updatedUser);
      })
    );
  }

  completeEnrollment(projectId: number, memberId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/projects/${projectId}/complete/${memberId}`, {});
  }

  uploadEvidence(projectId: number, memberId: number, evidenceUrl: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/projects/${projectId}/evidence/${memberId}`, { evidenceUrl });
  }
}
