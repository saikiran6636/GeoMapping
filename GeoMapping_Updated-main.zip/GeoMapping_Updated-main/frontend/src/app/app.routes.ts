import { Routes } from '@angular/router';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { RegisterComponent } from './components/register/register.component';
import { OrganizerLoginComponent } from './components/organizer-login/organizer-login.component';
import { OrganizerRegisterComponent } from './components/organizer-register/organizer-register.component';
import { LoginComponent } from './components/login/login.component';
import { MemberLoginComponent } from './components/member-login/member-login.component';
import { MemberRegisterComponent } from './components/member-register/member-register.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { OrganizerDashboardComponent } from './components/organizer-dashboard/organizer-dashboard.component';
import { MemberDashboardComponent } from './components/member-dashboard/member-dashboard.component';

export const routes: Routes = [
    { path: '', component: WelcomeComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'login', component: LoginComponent },

    // Organizer routes
    { path: 'organizer-login', component: OrganizerLoginComponent },
    { path: 'organizer-register', component: OrganizerRegisterComponent },
    { path: 'organizer', component: OrganizerDashboardComponent },

    // Member routes
    { path: 'member-login', component: MemberLoginComponent },
    { path: 'member-register', component: MemberRegisterComponent },
    { path: 'member', component: MemberDashboardComponent },

    // Admin routes
    { path: 'admin-login', component: AdminLoginComponent },
    { path: 'admin', component: AdminDashboardComponent },

    // Fallback
    { path: '**', redirectTo: '' }
];
