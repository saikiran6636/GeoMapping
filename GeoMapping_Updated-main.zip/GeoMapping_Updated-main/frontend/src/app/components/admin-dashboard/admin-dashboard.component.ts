import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService, Project } from '../../services/api.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dashboard-container">
      <!-- Header -->
      <div class="dash-header">
        <div>
          <h1>Admin Dashboard</h1>
          <p class="welcome-text">Manage project approvals</p>
        </div>
        <button class="btn-logout" (click)="logout()">Logout</button>
      </div>

      <!-- Stats -->
      <div class="stats-row">
        <div class="stat-card card-3d">
          <div class="stat-icon pending">⏳</div>
          <div class="stat-info">
            <div class="stat-value">{{ pendingProjects.length }}</div>
            <div class="stat-label">Pending</div>
          </div>
        </div>
        <div class="stat-card card-3d">
          <div class="stat-icon approved">✓</div>
          <div class="stat-info">
            <div class="stat-value">{{ approvedCount }}</div>
            <div class="stat-label">Approved</div>
          </div>
        </div>
        <div class="stat-card card-3d">
          <div class="stat-icon rejected">✕</div>
          <div class="stat-info">
            <div class="stat-value">{{ rejectedCount }}</div>
            <div class="stat-label">Rejected</div>
          </div>
        </div>
      </div>

      <!-- Pending Approvals -->
      <div class="section">
        <h3>📋 Pending Approvals</h3>
        
        <div *ngIf="pendingProjects.length === 0" class="empty-state">
          No pending projects to review.
        </div>

        <div class="projects-list">
          <div *ngFor="let project of pendingProjects" class="project-card card-3d">
            <div class="project-main">
              <div class="project-info">
                <h4>{{ project.name }}</h4>
                <p class="project-desc">{{ project.description }}</p>
                <div class="project-meta">
                  <span>📍 {{ project.location || 'No location' }}</span>
                  <span>👤 Organizer ID: {{ project.organizerId }}</span>
                  <span>🎁 {{ project.rewardPoints }} pts</span>
                </div>
                <div class="coords">
                  Coordinates: {{ project.latitude?.toFixed(4) }}, {{ project.longitude?.toFixed(4) }}
                </div>
              </div>
              <div class="project-actions">
                <button class="btn-approve" (click)="updateStatus(project, 'APPROVED')">
                  ✓ Approve
                </button>
                <button class="btn-reject" (click)="updateStatus(project, 'REJECTED')">
                  ✕ Reject
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }
    .dash-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .dash-header h1 {
      margin: 0;
      font-size: 2rem;
    }
    .welcome-text {
      color: #94a3b8;
      margin: 0.25rem 0 0;
    }
    .btn-logout {
      background: transparent;
      border: 1px solid #ef4444;
      color: #ef4444;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-logout:hover {
      background: #ef4444;
      color: white;
    }
    .stats-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.5rem;
      margin-bottom: 2rem;
    }
    .stat-card {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1.5rem;
    }
    .stat-icon {
      width: 50px;
      height: 50px;
      border-radius: 0.75rem;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
    }
    .stat-icon.pending { background: rgba(251, 191, 36, 0.2); }
    .stat-icon.approved { background: rgba(74, 222, 128, 0.2); }
    .stat-icon.rejected { background: rgba(239, 68, 68, 0.2); }
    .stat-value {
      font-size: 2rem;
      font-weight: 700;
    }
    .stat-label {
      color: #64748b;
      font-size: 0.9rem;
    }
    .section h3 {
      margin-bottom: 1.5rem;
    }
    .empty-state {
      text-align: center;
      padding: 3rem;
      color: #64748b;
      background: rgba(255,255,255,0.02);
      border-radius: 1rem;
      border: 1px dashed rgba(255,255,255,0.1);
    }
    .projects-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .project-card {
      padding: 1.5rem;
    }
    .project-main {
      display: flex;
      justify-content: space-between;
      gap: 2rem;
    }
    .project-info {
      flex: 1;
    }
    .project-info h4 {
      margin: 0 0 0.5rem;
      font-size: 1.25rem;
    }
    .project-desc {
      color: #94a3b8;
      margin-bottom: 0.75rem;
    }
    .project-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      font-size: 0.9rem;
      color: #64748b;
      margin-bottom: 0.5rem;
    }
    .coords {
      font-size: 0.85rem;
      color: #475569;
    }
    .project-actions {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      min-width: 120px;
    }
    .btn-approve, .btn-reject {
      padding: 0.75rem 1rem;
      border: none;
      border-radius: 0.5rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-approve {
      background: linear-gradient(135deg, #4ade80, #22c55e);
      color: #000;
    }
    .btn-reject {
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
    }
    .btn-approve:hover { transform: translateY(-2px); }
    .btn-reject:hover { transform: translateY(-2px); }
    @media (max-width: 768px) {
      .stats-row { grid-template-columns: 1fr; }
      .project-main { flex-direction: column; }
      .project-actions { flex-direction: row; }
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  pendingProjects: Project[] = [];
  approvedCount = 0;
  rejectedCount = 0;

  constructor(private api: ApiService, private router: Router) { }

  ngOnInit() {
    const user = this.api.getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      this.router.navigate(['/admin-login']);
      return;
    }
    this.loadProjects();
  }

  loadProjects() {
    this.api.getPendingProjects().subscribe(data => {
      this.pendingProjects = data;
    });
  }

  updateStatus(project: Project, status: string) {
    if (!project.id) return;

    this.api.updateProjectStatus(project.id, status).subscribe(() => {
      if (status === 'APPROVED') this.approvedCount++;
      if (status === 'REJECTED') this.rejectedCount++;
      this.loadProjects();
    });
  }

  logout() {
    this.api.logout();
    this.router.navigate(['/']);
  }
}
