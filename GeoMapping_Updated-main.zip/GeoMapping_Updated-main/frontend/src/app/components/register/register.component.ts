import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService, User } from '../../services/api.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="auth-container">
      <div class="auth-card card-3d">
        <div class="auth-header">
          <span class="role-badge" [ngClass]="role.toLowerCase()">
            {{ role === 'ORGANIZER' ? '🌱 Organizer' : '🌍 Member' }}
          </span>
          <h2>Create Account</h2>
          <p>Register as a {{ role | titlecase }} to get started</p>
        </div>
        
        <div *ngIf="error" class="error-msg">{{ error }}</div>
        <div *ngIf="success" class="success-msg">{{ success }}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" [(ngModel)]="user.name" name="name" placeholder="Enter your full name" required>
          </div>
          <div class="form-group">
            <label>Email Address</label>
            <input type="email" [(ngModel)]="user.email" name="email" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label>Mobile Phone Number</label>
            <input type="tel" [(ngModel)]="user.phoneNumber" name="phone" placeholder="Enter your 10-digit number" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" [(ngModel)]="user.password" name="password" placeholder="Create a strong password" required>
          </div>
          
          <!-- Location Fields for Members -->
          <div *ngIf="role === 'MEMBER'" class="form-group">
            <label>Your Location (for mapping)</label>
            <div class="location-inputs">
              <input type="number" [(ngModel)]="user.locationLat" name="lat" placeholder="Latitude" step="any">
              <input type="number" [(ngModel)]="user.locationLng" name="lng" placeholder="Longitude" step="any">
            </div>
            <button type="button" class="btn-location" (click)="getLocation()">
              📍 Use Current Location
            </button>
          </div>

          <button type="submit" class="btn-3d btn-full" [disabled]="loading"
                  [style.background]="role === 'MEMBER' ? 'linear-gradient(135deg, #60a5fa, #3b82f6)' : ''"
                  [style.color]="role === 'MEMBER' ? 'white' : ''">
            {{ redirecting ? 'Redirecting...' : (loading ? 'Creating Account...' : 'Register') }}
          </button>
        </form>

        <div class="auth-footer">
          <p>Already have an account?</p>
          <a [routerLink]="role === 'ORGANIZER' ? '/organizer-login' : '/member-login'" 
             class="link-primary"
             [style.color]="role === 'MEMBER' ? '#60a5fa' : ''">
            Login as {{ role | titlecase }}
          </a>
        </div>

        <a routerLink="/" class="back-link">← Back to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .auth-card {
      width: 100%;
      max-width: 450px;
    }
    .auth-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .auth-header h2 {
      margin: 1rem 0 0.5rem;
      font-size: 2.2rem;
    }
    .auth-header p {
      color: #94a3b8;
      font-size: 0.95rem;
    }
    .role-badge {
      display: inline-block;
      padding: 0.5rem 1.25rem;
      border-radius: 2rem;
      font-size: 0.9rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .role-badge.organizer {
      background: rgba(74, 222, 128, 0.15);
      color: #4ade80;
    }
    .role-badge.member {
      background: rgba(96, 165, 250, 0.15);
      color: #60a5fa;
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .location-inputs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
      margin-bottom: 0.5rem;
    }
    .btn-location {
      width: 100%;
      padding: 0.6rem;
      background: transparent;
      border: 1px dashed rgba(255,255,255,0.2);
      color: #94a3b8;
      border-radius: 0.5rem;
      cursor: pointer;
      font-size: 0.85rem;
      transition: all 0.2s;
    }
    .btn-location:hover {
      background: rgba(255,255,255,0.05);
      color: white;
      border-color: white;
    }
    .error-msg {
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
      border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .success-msg {
      background: rgba(74, 222, 128, 0.15);
      color: #4ade80;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
      border: 1px solid rgba(74, 222, 128, 0.2);
    }
    .btn-full {
      width: 100%;
      margin-top: 1rem;
    }
    .auth-footer {
      text-align: center;
      margin-top: 1.5rem;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    .auth-footer p {
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
    }
    .link-primary {
      color: #4ade80;
      text-decoration: none;
      font-weight: 600;
    }
    .link-primary:hover {
      text-decoration: underline;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 2rem;
      color: #64748b;
      text-decoration: none;
      font-size: 0.85rem;
    }
    .back-link:hover {
      color: #94a3b8;
    }
  `]
})
export class RegisterComponent implements OnInit {
  role: 'ORGANIZER' | 'MEMBER' = 'MEMBER';
  user: User = { role: 'MEMBER' };
  error = '';
  success = '';
  loading = false;
  redirecting = false;

  constructor(
    private api: ApiService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const r = params['role'];
      if (r === 'ORGANIZER' || r === 'MEMBER') {
        this.role = r;
        this.user.role = r;
      }
    });
  }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => {
          this.user.locationLat = p.coords.latitude;
          this.user.locationLng = p.coords.longitude;
        },
        () => this.error = 'Could not access location.'
      );
    }
  }

  onSubmit() {
    this.loading = true;
    this.error = '';
    this.success = '';

    this.api.register(this.user).subscribe({
      next: () => {
        this.success = 'Registration successful! Redirecting to login...';
        this.redirecting = true;
        // Keep loading=true to prevent re-submission, but we could update UI state if needed
        setTimeout(() => {
          this.router.navigate([this.role === 'ORGANIZER' ? '/organizer-login' : '/member-login']);
        }, 1000); // Reduced from 2000ms to 1000ms
      },
      error: (err) => {
        this.error = err.error?.error || 'Registration failed. Please check your data.';
        this.loading = false;
      }
    });
  }
}
