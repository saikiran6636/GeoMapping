import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
    selector: 'app-navbar',
    standalone: true,
    imports: [CommonModule, RouterModule],
    template: `
    <nav>
      <div class="logo">SustainableApp</div>
      <div>
        <a routerLink="/">Home</a>
        <ng-container *ngIf="api.user$ | async as user; else guest">
          <a *ngIf="user.role === 'ADMIN'" routerLink="/admin">Admin Dashboard</a>
          <a *ngIf="user.role === 'ORGANIZER'" routerLink="/organizer">My Projects</a>
          <a *ngIf="user.role === 'MEMBER'" routerLink="/member">Available Projects</a>
          <a (click)="logout()" style="cursor: pointer; color: var(--secondary)">Logout</a>
        </ng-container>
        <ng-template #guest>
          <a routerLink="/login">Login</a>
        </ng-template>
      </div>
    </nav>
  `
})
export class NavbarComponent {
    constructor(public api: ApiService, private router: Router) { }

    logout() {
        this.api.logout();
        this.router.navigate(['/']);
    }
}
