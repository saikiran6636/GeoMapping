import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-home',
    standalone: true,
    imports: [CommonModule, RouterModule],
    template: `
    <div class="container" style="text-align: center; margin-top: 4rem;">
      <h1 style="font-size: 4rem; margin-bottom: 1rem; background: linear-gradient(to right, #4ade80, #60a5fa); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
        Build a Greener Future
      </h1>
      <p style="font-size: 1.5rem; color: #94a3b8; margin-bottom: 3rem;">
        Join us in making the world a better place. Organize projects or contribute to existing ones.
      </p>
      <div class="grid grid-cols-2" style="gap: 4rem; max-width: 800px; margin: 0 auto;">
        <div class="card-3d">
          <h2 style="color: #4ade80;">Organizers</h2>
          <p style="margin-bottom: 1.5rem;">Create eco-friendly projects and get support.</p>
          <button class="btn-3d" routerLink="/register" [queryParams]="{role: 'ORGANIZER'}">Join as Organizer</button>
        </div>
        <div class="card-3d">
          <h2 style="color: #60a5fa;">Members</h2>
          <p style="margin-bottom: 1.5rem;">Volunteer near you and earn rewards.</p>
          <button class="btn-3d btn-secondary" routerLink="/register" [queryParams]="{role: 'MEMBER'}">Join as Member</button>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent { }
