import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, User } from '../../services/api.service';

@Component({
  selector: 'app-member-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="auth-container">
      <div class="auth-card card-3d">
        <div class="auth-header">
          <span class="role-badge member">🌍 Member</span>
          <h2>Register</h2>
          <p>Join and contribute to projects</p>
        </div>
        
        <div *ngIf="error" class="error-msg">{{ error }}</div>
        <div *ngIf="success" class="success-msg">{{ success }}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" [(ngModel)]="user.name" name="name" placeholder="Enter your full name" required>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" [(ngModel)]="user.email" name="email" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label>Mobile Phone Number</label>
            <input type="tel" [(ngModel)]="user.phoneNumber" name="phone" placeholder="Enter your 10-digit number" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" [(ngModel)]="user.password" name="password" placeholder="Create a password" required>
          </div>
          
          <div class="form-group">
            <label>Your Location</label>
            <div class="location-inputs">
              <input type="number" [(ngModel)]="user.locationLat" name="lat" placeholder="Latitude" step="any">
              <input type="number" [(ngModel)]="user.locationLng" name="lng" placeholder="Longitude" step="any">
            </div>
            <button type="button" class="btn-location" (click)="getLocation()">
              📍 Use Current Location
            </button>
          </div>

          <button type="submit" class="btn-3d btn-member btn-full" [disabled]="loading">
            <span *ngIf="loading" class="spinner"></span>
            {{ loading ? 'Registering...' : 'Register' }}
          </button>
        </form>

        <div class="auth-footer">
          <p>Already have an account?</p>
          <a routerLink="/member-login" class="link-primary">Login as Member</a>
        </div>

        <a routerLink="/" class="back-link">← Back to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .auth-card {
      width: 100%;
      max-width: 420px;
    }
    .auth-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .auth-header h2 {
      margin: 1rem 0 0.5rem;
      font-size: 2rem;
    }
    .auth-header p {
      color: #94a3b8;
      font-size: 0.9rem;
    }
    .role-badge {
      display: inline-block;
      padding: 0.5rem 1rem;
      border-radius: 2rem;
      font-size: 0.9rem;
      font-weight: 600;
    }
    .role-badge.member {
      background: rgba(96, 165, 250, 0.15);
      color: #60a5fa;
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .location-inputs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
      margin-bottom: 0.5rem;
    }
    .btn-location {
      width: 100%;
      padding: 0.5rem;
      background: transparent;
      border: 1px dashed #60a5fa;
      color: #60a5fa;
      border-radius: 0.5rem;
      cursor: pointer;
      font-size: 0.85rem;
      transition: all 0.2s;
    }
    .btn-location:hover {
      background: rgba(96, 165, 250, 0.1);
    }
    .error-msg {
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
    }
    .success-msg {
      background: rgba(74, 222, 128, 0.15);
      color: #4ade80;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
    }
    .btn-full {
      width: 100%;
      margin-top: 0.5rem;
    }
    .btn-member {
      background: linear-gradient(135deg, #60a5fa, #3b82f6) !important;
      color: white !important;
    }
    .auth-footer {
      text-align: center;
      margin-top: 1.5rem;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    .auth-footer p {
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
    }
    .link-primary {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }
    .link-primary:hover {
      text-decoration: underline;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 1.5rem;
      color: #64748b;
      text-decoration: none;
      font-size: 0.85rem;
    }
    .spinner {
      display: inline-block;
      width: 1rem;
      height: 1rem;
      border: 2px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: #fff;
      animation: spin 1s ease-in-out infinite;
      margin-right: 0.5rem;
      vertical-align: middle;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .back-link:hover {
      color: #94a3b8;
    }
  `]
})
export class MemberRegisterComponent {
  user: User = { role: 'MEMBER' };
  error = '';
  success = '';
  loading = false;

  constructor(private api: ApiService, private router: Router) { }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.user.locationLat = position.coords.latitude;
          this.user.locationLng = position.coords.longitude;
        },
        () => {
          this.error = 'Could not get your location';
        }
      );
    }
  }

  onSubmit() {
    this.loading = true;
    this.error = '';
    this.success = '';

    this.api.register(this.user).subscribe({
      next: () => {
        this.success = 'Registration successful! Redirecting to login...';
        this.success = 'Registration successful! Redirecting to login...';
        this.router.navigate(['/member-login']);
      },
      error: (err) => {
        this.error = err.error?.error || 'Registration failed. Please try again.';
        this.loading = false;
      }
    });
  }
}
