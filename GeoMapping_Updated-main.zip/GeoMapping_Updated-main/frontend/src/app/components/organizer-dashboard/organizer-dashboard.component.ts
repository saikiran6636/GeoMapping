import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService, Project, User } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-organizer-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="dashboard-container">
      <!-- Header -->
      <div class="dash-header">
        <div>
          <h1>Organizer Dashboard</h1>
          <p class="welcome-text">Welcome, {{ currentUser?.name || 'Organizer' }}</p>
        </div>
        <div class="header-actions">
          <button class="btn-edit" (click)="openEditProfile()">✏️ Edit Profile</button>
          <button class="btn-logout" (click)="logout()">Logout</button>
        </div>
      </div>
      
      <!-- Dashboard Notifications -->
      <div *ngIf="dashboardSuccessMsg" class="success-msg dashboard-alert">
        {{ dashboardSuccessMsg }}
      </div>

      <div class="dashboard-grid">
        <!-- Add Project Form -->
        <div class="card-3d form-card">
          <h3>📋 Add New Project</h3>
          
          <form (ngSubmit)="submitProject()">
            <div class="form-group">
              <label>Project Name</label>
              <input type="text" [(ngModel)]="newProject.name" name="name" placeholder="Enter project name" required>
            </div>
            
            <div class="form-group">
              <label>Description</label>
              <textarea [(ngModel)]="newProject.description" name="description" rows="4" placeholder="Describe your project..." required></textarea>
            </div>
            
            <div class="form-group">
              <label>Location Name</label>
              <input type="text" [(ngModel)]="newProject.location" name="location" placeholder="e.g., Central Park, New York">
            </div>
            
            <div class="form-group">
              <label>Coordinates</label>
              <div class="coord-inputs">
                <input type="number" [(ngModel)]="newProject.latitude" name="lat" placeholder="Latitude" step="any" required>
                <input type="number" [(ngModel)]="newProject.longitude" name="lng" placeholder="Longitude" step="any" required>
              </div>
            </div>

            <div class="form-group coord-inputs">
              <div>
                <label>Start Date</label>
                <input type="date" [(ngModel)]="newProject.startDate" name="start" required>
              </div>
              <div>
                <label>End Date</label>
                <input type="date" [(ngModel)]="newProject.endDate" name="end" required>
              </div>
            </div>

            <div class="form-group">
              <label>Reward Points (for contributors)</label>
              <input type="number" [(ngModel)]="newProject.rewardPoints" name="reward" placeholder="Points per contribution" min="1">
            </div>

            <div class="form-group">
              <label>Project Image URL</label>
              <input type="text" [(ngModel)]="newProject.imageUrl" name="img" placeholder="Paste image link here">
            </div>

            <button type="submit" class="btn-3d btn-submit" [disabled]="submitting">
              {{ submitting ? 'Processing...' : '🚀 Launch Project Now' }}
            </button>
          </form>

          <div *ngIf="errorMsg" class="error-msg">{{ errorMsg }}</div>
          <div *ngIf="successMsg" class="success-msg">{{ successMsg }}</div>
        </div>

        <!-- Projects Column -->
        <div class="projects-column">
          <!-- My Projects -->
          <div class="projects-section">
            <h3>📁 My Projects</h3>
            
            <div *ngIf="loadingProjects" class="loading-state">
              <div class="spinner"></div> Loading your projects...
            </div>

            <div *ngIf="!loadingProjects && myProjects.length === 0" class="empty-state">
              No projects yet. Create your first project!
            </div>

            <div class="projects-list" *ngIf="!loadingProjects && myProjects.length > 0">
              <div *ngFor="let project of myProjects" class="project-card card-3d" [class.temp-item]="!project.id">
                <div class="project-header">
                  <h4>{{ project.name }}</h4>
                  <span class="status-badge" [ngClass]="project.status?.toLowerCase()">{{ project.status }}</span>
                </div>
                <div class="project-image" *ngIf="project.imageUrl" style="height: 120px; margin: -1rem -1rem 1rem -1rem; overflow: hidden; border-radius: 1rem 1rem 0 0;">
                  <img [src]="project.imageUrl" alt="Project image" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <div class="project-image placeholder" *ngIf="!project.imageUrl" style="height: 120px; margin: -1rem -1rem 1rem -1rem; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; font-size: 2rem; border-radius: 1rem 1rem 0 0;">
                  <span>🖼️</span>
                </div>
                
                <p class="project-desc">{{ project.description }}</p>
                <div class="project-meta">
                  <span>📍 {{ project.location || 'No location' }}</span>
                  <span>🎁 {{ project.rewardPoints }} pts</span>
                </div>
                <div class="project-dates" *ngIf="project.startDate">
                  📅 <strong>{{ project.startDate | date:'mediumDate' }}</strong> to <strong>{{ project.endDate | date:'mediumDate' }}</strong>
                </div>
                <div class="project-coords">
                  Lat: {{ project.latitude?.toFixed(4) }}, Lng: {{ project.longitude?.toFixed(4) }}
                </div>
                
                <div class="project-actions">
                  <button class="btn-action btn-edit-project" 
                          (click)="project.id && openEditProject(project)" 
                          [disabled]="!project.id">
                    ✏️ Edit
                  </button>
                  <button class="btn-action btn-delete" 
                          (click)="project.id && deleteProject(project.id)" 
                          [disabled]="!project.id">
                    🗑️ Delete
                  </button>
                  <button class="btn-action btn-members" 
                          (click)="project.id && toggleMembers(project.id)" 
                          [disabled]="!project.id">
                    👥 {{ viewingMembers === project.id ? 'Hide' : 'View' }} Members
                  </button>
                </div>

                <!-- Members Tracking Report Dropdown -->
                <div *ngIf="viewingMembers === project.id" class="members-dropdown full-width">
                  <div class="report-header">
                    <h4>📊 Member Tracking Report</h4>
                    <button class="btn-refresh-report" (click)="toggleMembers(project.id)">🔄 Refresh</button>
                  </div>

                  <div *ngIf="loadingMembers" class="loading-state">
                    <div class="spinner"></div> Loading member tracks...
                  </div>
                  
                  <div *ngIf="!loadingMembers && enrolledMembers.length === 0" class="empty-state mini">
                    No members enrolled yet.
                  </div>

                  <div *ngIf="!loadingMembers && enrolledMembers.length > 0" class="table-container">
                    <table class="report-table">
                      <thead>
                        <tr>
                          <th>Member</th>
                          <th>Enrolled At</th>
                          <th>Status</th>
                          <th>Evidence</th>
                          <th>Completion Date</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr *ngFor="let m of enrolledMembers">
                          <td>
                            <div class="member-cell">
                              <div class="member-avatar small">{{ m.name.charAt(0) }}</div>
                              <div class="member-name-stack">
                                <strong>{{ m.name }}</strong>
                                <span>{{ m.email }}</span>
                              </div>
                            </div>
                          </td>
                          <td>{{ m.enrolledAt | date:'mediumDate' }}</td>
                          <td>
                            <span class="status-chip" [class.done]="m.status === 'COMPLETED'">
                              {{ m.status || 'IN_PROGRESS' }}
                            </span>
                          </td>
                          <td>
                            <button *ngIf="m.evidenceUrl" (click)="viewEvidence(m.evidenceUrl)" class="btn-table btn-view-proof">
                              🖼️ View Proof
                            </button>
                            <span *ngIf="!m.evidenceUrl" style="color: #64748b; font-size: 0.8rem;">No proof yet</span>
                          </td>
                          <td>{{ m.completionDate ? (m.completionDate | date:'mediumDate') : '---' }}</td>
                          <td>
                            <button class="btn-table btn-complete" 
                                    *ngIf="m.status !== 'COMPLETED'"
                                    (click)="markAsCompleted(project.id, m.id)">
                              ✅ Complete
                            </button>
                            <span *ngIf="m.status === 'COMPLETED'">Verified 🎯</span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <!-- Simple Map Preview -->
                <div class="map-preview">
                  <iframe 
                    [src]="getMapUrl(project)" 
                    width="100%" 
                    height="120" 
                    style="border:0; border-radius: 0.5rem;" 
                    loading="lazy">
                  </iframe>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <!-- Edit Profile Modal -->
      <div class="modal-overlay" *ngIf="showEditProfile" (click)="showEditProfile = false">
        <div class="modal-content" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>✏️ Edit Profile</h2>
            <button class="btn-close" (click)="showEditProfile = false">×</button>
          </div>
          
          <div class="modal-body">
            <form (ngSubmit)="saveProfile()">
              <div class="form-group">
                <label>Name</label>
                <input type="text" [(ngModel)]="editForm.name" name="name" required>
              </div>

              <div class="form-group">
                <label>Email</label>
                <input type="email" [(ngModel)]="editForm.email" name="email" required>
              </div>

              <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" [(ngModel)]="editForm.phoneNumber" name="phone">
              </div>

              <div *ngIf="editError" class="error-msg">{{ editError }}</div>
              <div *ngIf="editSuccess" class="success-msg">{{ editSuccess }}</div>

              <div class="modal-actions">
                <button type="button" class="btn-cancel" (click)="showEditProfile = false">Cancel</button>
                <button type="submit" class="btn-save" [disabled]="saving">
                  {{ saving ? 'Saving...' : 'Save Changes' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Edit Project Modal -->
      <div class="modal-overlay" *ngIf="showEditProject" (click)="showEditProject = false">
        <div class="modal-content" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>✏️ Edit Project</h2>
            <button class="btn-close" (click)="showEditProject = false">×</button>
          </div>
          
          <div class="modal-body">
            <form (ngSubmit)="saveProject()">
              <div class="form-group">
                <label>Project Name</label>
                <input type="text" [(ngModel)]="editProjectForm.name" name="name" required>
              </div>

              <div class="form-group">
                <label>Description</label>
                <textarea [(ngModel)]="editProjectForm.description" name="description" rows="4" required></textarea>
              </div>

              <div class="form-group">
                <label>Location Name</label>
                <input type="text" [(ngModel)]="editProjectForm.location" name="location">
              </div>

              <div class="form-group">
                <label>Coordinates</label>
                <div class="coord-inputs">
                  <input type="number" [(ngModel)]="editProjectForm.latitude" name="lat" placeholder="Latitude" step="any" required>
                  <input type="number" [(ngModel)]="editProjectForm.longitude" name="lng" placeholder="Longitude" step="any" required>
                </div>
              </div>

              <div class="form-group coord-inputs">
                <div>
                  <label>Start Date</label>
                  <input type="date" [(ngModel)]="editProjectForm.startDate" name="start" required>
                </div>
                <div>
                  <label>End Date</label>
                  <input type="date" [(ngModel)]="editProjectForm.endDate" name="end" required>
                </div>
              </div>

              <div class="form-group">
                <label>Reward Points</label>
                <input type="number" [(ngModel)]="editProjectForm.rewardPoints" name="reward" min="1">
              </div>

              <div class="form-group">
                <label>Project Image URL</label>
                <input type="text" [(ngModel)]="editProjectForm.imageUrl" name="img" placeholder="Paste image link here">
              </div>

              <div *ngIf="editProjectError" class="error-msg">{{ editProjectError }}</div>
              <div *ngIf="editProjectSuccess" class="success-msg">{{ editProjectSuccess }}</div>

              <div class="modal-actions">
                <button type="button" class="btn-cancel" (click)="showEditProject = false">Cancel</button>
                <button type="submit" class="btn-save" [disabled]="savingProject">
                  {{ savingProject ? 'Saving...' : 'Save Changes' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }
    .dash-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .dash-header h1 {
      margin: 0;
      font-size: 2rem;
    }
    .welcome-text {
      color: #94a3b8;
      margin: 0.25rem 0 0;
    }
    .header-actions {
      display: flex;
      gap: 1rem;
    }
    .btn-edit {
      background: rgba(96, 165, 250, 0.2);
      border: 1px solid #60a5fa;
      color: #60a5fa;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-edit:hover {
      background: rgba(96, 165, 250, 0.3);
    }
    .btn-logout {
      background: transparent;
      border: 1px solid #ef4444;
      color: #ef4444;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-logout:hover {
      background: #ef4444;
      color: white;
    }
    .dashboard-grid {
      display: grid;
      grid-template-columns: 400px 1fr;
      gap: 2rem;
      align-items: start;
    }
    @media (max-width: 1024px) {
      .dashboard-grid { grid-template-columns: 1fr; }
    }
    .form-card h3 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: #4ade80;
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .form-group input, .form-group textarea {
      width: 100%;
      padding: 0.75rem;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 0.5rem;
      color: white;
      font-size: 1rem;
    }
    .coord-inputs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
    }
    .btn-submit {
      width: 100%;
      margin-top: 0.5rem;
      background: linear-gradient(135deg, #4ade80, #22c55e);
      color: white;
      border: none;
      padding: 0.8rem;
      border-radius: 0.5rem;
      font-weight: 600;
      cursor: pointer;
    }
    .btn-submit:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }
    .success-msg {
      margin-top: 1rem;
      padding: 0.75rem;
      background: rgba(74, 222, 128, 0.15);
      color: #4ade80;
      border-radius: 0.5rem;
      text-align: center;
    }
    .error-msg {
      margin-top: 1rem;
      padding: 0.75rem;
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      border-radius: 0.5rem;
      text-align: center;
      border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .projects-section h3 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: #60a5fa;
    }
    .empty-state {
      text-align: center;
      padding: 3rem;
      color: #64748b;
      background: rgba(255,255,255,0.02);
      border-radius: 1rem;
      border: 1px dashed rgba(255,255,255,0.1);
    }
    .loading-state {
      text-align: center;
      padding: 3rem;
      color: #94a3b8;
    }
    .spinner {
      display: inline-block;
      width: 1.5rem;
      height: 1.5rem;
      border: 3px solid rgba(255,255,255,0.1);
      border-radius: 50%;
      border-top-color: #60a5fa;
      animation: spin 1s ease-in-out infinite;
      vertical-align: middle;
      margin-right: 0.5rem;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .projects-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1rem;
    }
    .project-card {
      padding: 1.25rem;
      background: rgba(255,255,255,0.03);
    }
    .project-card.temp-item {
      opacity: 0.7;
      border: 1px dashed #4ade80;
    }
    .project-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.75rem;
    }
    .project-header h4 {
      margin: 0;
      font-size: 1.1rem;
      color: white;
    }
    .status-badge {
      padding: 0.2rem 0.6rem;
      border-radius: 1rem;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
    }
    .status-badge.pending { background: rgba(251, 191, 36, 0.2); color: #fbbf24; }
    .status-badge.approved { background: rgba(74, 222, 128, 0.2); color: #4ade80; }
    .project-desc {
      color: #94a3b8;
      font-size: 0.85rem;
      margin-bottom: 0.75rem;
      height: 2.5rem;
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
    .project-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      font-size: 0.8rem;
      color: #64748b;
      margin-bottom: 0.5rem;
    }
    .project-coords {
      font-size: 0.75rem;
      color: #475569;
      margin-bottom: 0.75rem;
    }
    .project-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
      margin-bottom: 1rem;
    }
    .btn-action {
      padding: 0.5rem;
      border-radius: 0.5rem;
      cursor: pointer;
      font-size: 0.85rem;
      transition: all 0.2s;
      border: 1px solid rgba(255,255,255,0.1);
    }
    .btn-edit-project {
      background: rgba(96, 165, 250, 0.2);
      color: #60a5fa;
    }
    .btn-edit-project:hover {
      background: rgba(96, 165, 250, 0.3);
    }
    .btn-delete {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }
    .btn-delete:hover {
      background: rgba(239, 68, 68, 0.3);
    }
    .btn-members {
      grid-column: 1 / -1;
      background: rgba(255,255,255,0.05);
      color: #94a3b8;
    }
    .btn-members:hover {
      background: rgba(255,255,255,0.1);
      color: white;
    }
    .btn-action:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .members-dropdown {
      background: rgba(0,0,0,0.2);
      border-radius: 0.5rem;
      padding: 0.75rem;
      margin-bottom: 1rem;
      border: 1px solid rgba(255,255,255,0.05);
    }
    .loading-text, .no-members {
      color: #64748b;
      font-size: 0.85rem;
      text-align: center;
      padding: 0.5rem;
    }
    .members-list-scroll {
      max-height: 150px;
      overflow-y: auto;
    }
    .member-item {
      display: flex;
      align-items: center;
      padding: 0.5rem;
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .member-item:last-child {
      border-bottom: none;
    }
    .member-avatar {
      width: 30px;
      height: 30px;
      background: #3b82f6;
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.8rem;
      margin-right: 0.75rem;
      font-weight: 600;
    }
    .member-info {
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    .member-name {
      font-size: 0.85rem;
      color: #e2e8f0;
    }
    .member-email {
      font-size: 0.75rem;
      color: #64748b;
    }
    .project-dates {
      font-size: 0.85rem;
      background: rgba(255,255,255,0.03);
      padding: 0.5rem;
      border-radius: 0.5rem;
      margin: 0.75rem 0;
      border: 1px solid rgba(255,255,255,0.05);
    }
    .members-dropdown.full-width {
      grid-column: 1 / -1;
      background: #0f172a;
      border: 1px solid #1e293b;
      margin-top: 1rem;
      padding: 1.5rem;
      border-radius: 1rem;
    }
    .report-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    .table-container {
      overflow-x: auto;
    }
    .report-table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }
    .report-table th {
      padding: 1rem;
      background: #1e293b;
      color: #94a3b8;
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .report-table td {
      padding: 1rem;
      border-bottom: 1px solid #1e293b;
      font-size: 0.9rem;
    }
    .member-cell {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .member-avatar.small {
      width: 32px;
      height: 32px;
      font-size: 0.8rem;
    }
    .member-name-stack {
      display: flex;
      flex-direction: column;
    }
    .member-name-stack span {
      font-size: 0.75rem;
      color: #64748b;
    }
    .status-chip {
      padding: 0.25rem 0.6rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      background: #334155;
      color: #94a3b8;
    }
    .status-chip.done {
      background: rgba(34, 197, 94, 0.1);
      color: #22c55e;
      border: 1px solid rgba(34, 197, 94, 0.2);
    }
    .btn-table {
      padding: 0.4rem 0.8rem;
      border-radius: 0.4rem;
      font-size: 0.8rem;
      cursor: pointer;
      border: none;
      transition: all 0.2s;
    }
    .btn-complete {
      background: #22c55e;
      color: white;
    }
    .btn-complete:hover {
      background: #16a34a;
    }
    .btn-refresh-report {
      background: transparent;
      border: 1px solid #334155;
      color: #94a3b8;
      padding: 0.3rem 0.6rem;
      border-radius: 0.4rem;
      cursor: pointer;
    }
    .map-preview {
      border-radius: 0.5rem;
      overflow: hidden;
      border: 1px solid rgba(255,255,255,0.05);
    }

    /* Modal Styles */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      animation: fadeIn 0.2s;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    .modal-content {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      border-radius: 1rem;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow: hidden;
      box-shadow: 0 25px 50px rgba(0,0,0,0.5);
      animation: slideUp 0.3s;
    }
    @keyframes slideUp {
      from { transform: translateY(50px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
    }
    .btn-close {
      background: none;
      border: none;
      color: #94a3b8;
      font-size: 2rem;
      cursor: pointer;
      line-height: 1;
      transition: color 0.2s;
    }
    .btn-close:hover {
      color: #fff;
    }
    .modal-body {
      padding: 1.5rem;
      max-height: calc(80vh - 100px);
      overflow-y: auto;
    }
    .modal-actions {
      display: flex;
      gap: 1rem;
      margin-top: 1.5rem;
    }
    .btn-cancel {
      flex: 1;
      padding: 0.75rem;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: #94a3b8;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-cancel:hover {
      background: rgba(255,255,255,0.1);
    }
    .btn-save {
      flex: 1;
      padding: 0.75rem;
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      border: none;
      color: white;
      border-radius: 0.5rem;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.2s;
    }
    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(96, 165, 250, 0.4);
    }
    .dashboard-alert {
      margin-bottom: 2rem;
      animation: slideIn 0.3s;
    }
    @keyframes slideIn {
      from { transform: translateY(-20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .btn-save:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `]
})
export class OrganizerDashboardComponent implements OnInit {
  currentUser: User | null = null;
  myProjects: Project[] = [];
  allProjects: Project[] = [];
  newProject: Project = {
    name: '',
    description: '',
    latitude: 0,
    longitude: 0,
    rewardPoints: 10,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  };
  submitting = false;
  successMsg = '';
  errorMsg = '';
  loadingProjects = true;

  // Member View Logic
  viewingMembers: number | null = null;
  enrolledMembers: any[] = [];
  loadingMembers = false;

  // Edit Profile
  showEditProfile = false;
  editForm: any = {};
  saving = false;
  editError = '';
  editSuccess = '';

  // Edit Project
  showEditProject = false;
  editProjectForm: any = {};
  editingProjectId: number | null = null;
  savingProject = false;
  editProjectError = '';
  editProjectSuccess = '';

  constructor(
    private api: ApiService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) { }

  ngOnInit() {
    this.currentUser = this.api.getCurrentUser();
    if (!this.currentUser || this.currentUser.role !== 'ORGANIZER') {
      this.router.navigate(['/organizer-login']);
      return;
    }
    this.loadProjects();
  }

  loadProjects() {
    this.errorMsg = '';
    this.loadingProjects = true;
    console.log('Loading projects for organizer:', this.currentUser?.id);
    if (this.currentUser?.id) {
      // My Projects
      this.api.getOrganizerProjects(this.currentUser.id).subscribe({
        next: (data) => {
          console.log('My projects loaded:', data ? data.length : 0);
          this.myProjects = data || [];
          this.loadingProjects = false;
        },
        error: (err) => {
          console.error('Failed to load my projects', err);
          this.errorMsg = 'Could not load projects. Please try again.';
          this.loadingProjects = false;
        }
      });
    } else {
      this.loadingProjects = false;
    }
  }

  submitProject() {
    if (!this.currentUser) return;

    this.submitting = true;
    this.errorMsg = '';

    // Prepare data
    const projectToSubmit: Project = {
      ...this.newProject,
      organizerId: this.currentUser.id,
      organizerName: this.currentUser.name || this.currentUser.username,
      status: 'PENDING'
    };

    // OPTIMISTIC UPDATE: Add to list immediately
    this.myProjects.push(projectToSubmit);

    // Clear form immediately
    this.newProject = {
      name: '',
      description: '',
      latitude: 0,
      longitude: 0,
      rewardPoints: 10,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
    };
    this.successMsg = '✨ Project launched! Syncing...';

    // Send to backend
    this.api.requestProject(projectToSubmit).subscribe({
      next: (saved) => {
        // Success
        this.successMsg = '✨ Project confirmed!';

        // Update the optimistic item with the real one
        const index = this.myProjects.indexOf(projectToSubmit);
        if (index !== -1) {
          this.myProjects[index] = saved;
        } else {
          this.myProjects.push(saved);
        }

        this.submitting = false;
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: (err) => {
        console.error('Error saving project:', err);
        this.successMsg = ''; // Clear success message on error
        this.errorMsg = err.error?.message || 'Failed to submit project. Please try again.';

        // ROLLBACK
        const index = this.myProjects.indexOf(projectToSubmit);
        if (index !== -1) {
          this.myProjects.splice(index, 1);
        }

        this.submitting = false;
      }
    });
  }

  toggleMembers(projectId: number) {
    if (this.viewingMembers === projectId) {
      this.closeMembers();
      return;
    }

    this.viewingMembers = projectId;
    this.loadingMembers = true;
    this.enrolledMembers = [];

    this.api.getProjectMembers(projectId).subscribe({
      next: (data) => {
        this.ngZone.run(() => {
          this.enrolledMembers = data;
          this.loadingMembers = false;
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        console.error('Failed to load members', err);
        this.loadingMembers = false;
        this.cdr.detectChanges();
      }
    });
  }

  viewEvidence(url: string) {
    window.open(url, '_blank');
  }

  markAsCompleted(projectId: number, memberId: number) {
    if (!confirm("Mark this member's contribution as completed?")) return;

    this.api.completeEnrollment(projectId, memberId).subscribe({
      next: () => {
        this.ngZone.run(() => {
          const m = this.enrolledMembers.find(member => member.id === memberId);
          if (m) {
            m.status = 'COMPLETED';
            m.completionDate = new Date().toISOString();
          }
          this.showDashboardSuccess('✅ Member contribution verified!');
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        console.error('Failed to complete enrollment', err);
        alert('Failed to update status. Please try again.');
      }
    });
  }

  closeMembers() {
    this.viewingMembers = null;
    this.enrolledMembers = [];
  }

  openEditProfile() {
    this.editForm = {
      name: this.currentUser?.name || '',
      email: this.currentUser?.email || '',
      phoneNumber: this.currentUser?.phoneNumber || ''
    };
    this.editError = '';
    this.editSuccess = '';
    this.showEditProfile = true;
  }

  // Dashboard notification helper
  dashboardSuccessMsg = '';
  showDashboardSuccess(msg: string) {
    this.dashboardSuccessMsg = msg;
    setTimeout(() => this.dashboardSuccessMsg = '', 3000);
  }

  saveProfile() {
    if (!this.currentUser?.id) return;

    this.saving = true;
    this.editError = '';
    this.editSuccess = '';

    this.api.updateProfile(this.currentUser.id, this.editForm).subscribe({
      next: (updatedUser) => {
        this.ngZone.run(() => {
          console.log('Profile update success:', updatedUser);
          this.saving = false;
          this.showEditProfile = false;
          this.currentUser = updatedUser;
          this.showDashboardSuccess('✅ Profile updated successfully!');
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        this.editError = err.error?.error || 'Failed to update profile';
        this.saving = false;
      }
    });
  }

  openEditProject(project: Project) {
    this.editingProjectId = project.id || null;
    this.editProjectForm = {
      name: project.name,
      description: project.description,
      location: project.location || '',
      latitude: project.latitude,
      longitude: project.longitude,
      rewardPoints: project.rewardPoints || 10,
      startDate: project.startDate,
      endDate: project.endDate,
      imageUrl: project.imageUrl
    };
    this.editProjectError = '';
    this.editProjectSuccess = '';
    this.showEditProject = true;
  }

  saveProject() {
    if (!this.editingProjectId) return;

    this.savingProject = true;
    this.editProjectError = '';
    this.editProjectSuccess = '';

    this.api.updateProject(this.editingProjectId, this.editProjectForm).subscribe({
      next: (updatedProject) => {
        this.ngZone.run(() => {
          console.log('Project update success:', updatedProject);
          this.savingProject = false;
          this.showEditProject = false;

          // Update in list
          const index = this.myProjects.findIndex(p => p.id === this.editingProjectId);
          if (index !== -1) {
            this.myProjects[index] = updatedProject;
          }

          this.showDashboardSuccess('✅ Project updated successfully!');
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        this.editProjectError = err.error?.message || 'Failed to update project';
        this.savingProject = false;
      }
    });
  }

  deleteProject(projectId: number) {
    if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      return;
    }

    // Optimistic delete
    const index = this.myProjects.findIndex(p => p.id === projectId);
    const deletedProject = index !== -1 ? this.myProjects[index] : null;

    if (index !== -1) {
      this.myProjects.splice(index, 1);
    }

    this.api.deleteProject(projectId).subscribe({
      next: () => {
        // Success - already removed from UI
        this.successMsg = 'Project deleted successfully!';
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: (err) => {
        console.error('Delete failed:', err);
        this.errorMsg = 'Failed to delete project';

        // Rollback
        if (deletedProject && index !== -1) {
          this.myProjects.splice(index, 0, deletedProject);
        }
      }
    });
  }

  getMapUrl(project: Project): SafeResourceUrl {
    const url = `https://www.openstreetmap.org/export/embed.html?bbox=${(project.longitude || 0) - 0.01},${(project.latitude || 0) - 0.01},${(project.longitude || 0) + 0.01},${(project.latitude || 0) + 0.01}&layer=mapnik&marker=${project.latitude},${project.longitude}`;
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  logout() {
    this.api.logout();
    this.router.navigate(['/']);
  }
}
