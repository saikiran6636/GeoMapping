import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService, Project, User, Enrollment } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-member-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="dashboard-container">
      <!-- Header -->
      <div class="dash-header">
        <div>
          <h1>Member Dashboard</h1>
          <p class="welcome-text">Welcome, {{ currentUser?.name || 'Member' }}</p>
        </div>
        <div class="header-actions">
          <button class="btn-rewards" (click)="showRewardsModal = true">
            🎁 <span>{{ currentUser?.rewardPoints || 0 }}</span> Points
          </button>
          <button class="btn-edit" (click)="openEditProfile()">✏️ Edit Profile</button>
          <button class="btn-logout" (click)="logout()">Logout</button>
        </div>
      </div>

      <!-- Dashboard Notifications -->
      <div *ngIf="dashboardSuccessMsg" class="success-msg dashboard-alert">
        {{ dashboardSuccessMsg }}
      </div>

      <div class="dashboard-grid">
        <!-- User Profile Card -->
        <div class="card-3d profile-card">
          <h3>👤 My Profile</h3>
          <div class="profile-info">
            <div class="info-row">
              <span class="label">Name:</span>
              <span class="value">{{ currentUser?.name }}</span>
            </div>
            <div class="info-row">
              <span class="label">Email:</span>
              <span class="value">{{ currentUser?.email }}</span>
            </div>
            <div class="info-row">
              <span class="label">Phone:</span>
              <span class="value">{{ currentUser?.phoneNumber || 'Not set' }}</span>
            </div>
            <div class="info-row">
              <span class="label">Location:</span>
              <span class="value">{{ currentUser?.locationLat?.toFixed(4) }}, {{ currentUser?.locationLng?.toFixed(4) }}</span>
            </div>
          </div>
          
          <div class="stats-grid">
            <div class="stat-box">
              <div class="stat-value">{{ enrollments.length }}</div>
              <div class="stat-label">Enrolled</div>
            </div>
            <div class="stat-box rewards">
              <div class="stat-value">{{ currentUser?.rewardPoints || 0 }}</div>
              <div class="stat-label">Total Points</div>
            </div>
          </div>
        </div>

        <!-- Available Projects -->
        <div class="projects-section">
          <div class="section-header">
            <h3>🌍 Available Projects</h3>
            <div class="search-wrapper" style="margin-left: 20px; flex: 1; max-width: 300px;">
                <input type="text" [(ngModel)]="searchTerm" placeholder="Search projects..." class="search-input" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc; background: rgba(255,255,255,0.1); color: white;">
            </div>
            <div class="filter-location">
              <button class="btn-filter" (click)="filterByLocation()" [class.active]="filterNearby">
                📍 Near Me
              </button>
            </div>
          </div>

          <div *ngIf="projects.length === 0" class="empty-state">
            No projects available at the moment.
          </div>

          <div class="projects-grid">
            <div *ngFor="let project of filteredProjects" class="project-card card-3d">
              <div class="project-header">
                <h4>{{ project.name }}</h4>
                <span class="reward-tag">🎁 {{ project.rewardPoints }} pts</span>
              </div>
              
              <p class="project-desc">{{ project.description }}</p>
              
              <div class="project-image" *ngIf="project.imageUrl">
                <img [src]="project.imageUrl" alt="Project image">
              </div>
              <div class="project-image placeholder" *ngIf="!project.imageUrl">
                <span>🌍</span>
              </div>
              
              <div class="project-meta">
                <span>📍 {{ project.location || 'Unknown location' }}</span>
                <span>👤 {{ project.organizerName }}</span>
              </div>

              <div class="project-distance" *ngIf="currentUser?.locationLat">
                ~{{ calculateDistance(project) }} km away
              </div>

              <!-- Map Preview -->
              <div class="map-preview">
                <iframe 
                  [src]="getMapUrl(project)" 
                  width="100%" 
                  height="120" 
                  style="border:0; border-radius: 0.5rem;" 
                  loading="lazy">
                </iframe>
              </div>

              <button 
                class="btn-3d btn-enroll" 
                (click)="enrollInProject(project)"
                [disabled]="isEnrolled(project.id!)">
                {{ isEnrolled(project.id!) ? '✓ Enrolled' : 'Enroll & Earn Points' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Rewards Modal -->
      <div class="modal-overlay" *ngIf="showRewardsModal" (click)="showRewardsModal = false">
        <div class="modal-content" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>🎁 My Rewards Breakdown</h2>
            <button class="btn-close" (click)="showRewardsModal = false">×</button>
          </div>
          
          <div class="modal-body">
            <div class="rewards-tracker-container">
              <div class="tracker-header">
                <h3>Your Eco-Journey 🚀</h3>
                <div class="current-points-badge">
                  <span>{{ currentUser?.rewardPoints || 0 }}</span> Points
                </div>
              </div>

              <div class="progress-track">
                <div class="progress-fill" [style.width.%]="rewardProgress">
                  <div class="progress-char">🌱</div>
                </div>
                <div class="milestone-markers">
                  <div *ngFor="let m of milestones" 
                       class="milestone-node" 
                       [class.reached]="isMilestoneReached(m.points)"
                       [style.left.%]="(m.points / 1000) * 100">
                    <div class="milestone-icon">{{ m.icon }}</div>
                    <div class="milestone-label">{{ m.points }}</div>
                  </div>
                </div>
              </div>

              <div class="next-reward-tip" *ngIf="rewardProgress < 100">
                Next up: <strong>{{ getNextMilestone().label }}</strong> at {{ getNextMilestone().points }} pts! Keep going! 🌟
              </div>
              <div class="next-reward-tip success" *ngIf="rewardProgress >= 100">
                You've reached the final milestone! You're an Eco Hero! 🏆
              </div>
            </div>

            <div *ngIf="loadingRewards" class="loading-state">
              <div class="spinner"></div> Loading rewards...
            </div>

            <div *ngIf="!loadingRewards && rewardsBreakdown.length === 0" class="empty-rewards">
              <span *ngIf="(currentUser?.rewardPoints || 0) === 0">
                No rewards earned yet. Enroll in projects to start earning!
              </span>
              <span *ngIf="(currentUser?.rewardPoints || 0) > 0">
                Points earned from past activities. Details for deleted projects are not available.
              </span>
            </div>

            <div class="rewards-list" *ngIf="!loadingRewards && rewardsBreakdown.length > 0">
              <div *ngFor="let reward of rewardsBreakdown" class="reward-item">
                <div class="reward-icon">🌱</div>
                <div class="reward-details">
                  <div class="reward-project">{{ reward.projectName }}</div>
                  <div class="reward-desc">{{ reward.projectDescription }}</div>
                  <div class="reward-organizer">by {{ reward.organizerName }}</div>
                  <div class="reward-date">{{ reward.enrolledAt | date:'medium' }}</div>
                </div>
                <div class="reward-points">+{{ reward.pointsEarned }} pts</div>
                <div class="reward-actions">
                  <!-- Evidence Upload/View -->
                  <button class="btn-evidence" *ngIf="reward.status !== 'COMPLETED' && !reward.evidenceUrl" (click)="openEvidenceUpload(reward)">
                    📸 Upload Proof
                  </button>
                  <div class="evidence-preview" *ngIf="reward.evidenceUrl">
                    <span class="evidence-check">✅ Proof Sent</span>
                    <button class="btn-view-evidence" (click)="viewEvidence(reward.evidenceUrl)">View</button>
                  </div>

                  <!-- Certificate -->
                  <button class="btn-download-cert" *ngIf="reward.status === 'COMPLETED'" (click)="generateCertificate(reward)">
                    📜 Certificate
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Evidence Upload Modal -->
      <div class="modal-overlay" *ngIf="showEvidenceModal" (click)="showEvidenceModal = false">
        <div class="modal-content small-modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>📸 Upload Evidence</h3>
            <button class="btn-close" (click)="showEvidenceModal = false">×</button>
          </div>
          <div class="modal-body">
            <p>Paste an image URL or base64 data to prove your contribution:</p>
            <textarea [(ngModel)]="evidenceUrlInput" placeholder="https://example.com/photo.jpg" rows="4" class="evidence-input"></textarea>
            <div class="modal-actions">
              <button class="btn-cancel" (click)="showEvidenceModal = false">Cancel</button>
              <button class="btn-save" (click)="submitEvidence()" [disabled]="!evidenceUrlInput">🚀 Submit Proof</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Certificate Modal -->
      <div class="modal-overlay" *ngIf="showCertificateModal" (click)="showCertificateModal = false">
        <div class="modal-content certificate-frame" (click)="$event.stopPropagation()">
            <div id="certificate-print-area" class="certificate-content">
                <div class="cert-border">
                    <div class="cert-header">
                        <div class="cert-logo">🌳</div>
                        <h1>Eco-Hero Certificate</h1>
                        <p>Official Recognition of Sustanability Excellence</p>
                    </div>
                    <div class="cert-body">
                        <p class="award-text">This is to certify that</p>
                        <h2 class="recipient-name">{{ currentUser?.name }}</h2>
                        <p class="accomplishment-text">
                            has successfully completed the project
                        </p>
                        <h3 class="cert-project-name">{{ selectedReward?.projectName }}</h3>
                        <p class="cert-details">
                            Verified on {{ selectedReward?.completionDate | date:'longDate' }} <br>
                            Earned <strong>{{ selectedReward?.pointsEarned }}</strong> Sustainability Points
                        </p>
                    </div>
                    <div class="cert-footer">
                        <div class="signature">
                            <div class="sig-line"></div>
                            <p>Project Organizer: {{ selectedReward?.organizerName }}</p>
                        </div>
                        <div class="seal">🏆</div>
                    </div>
                </div>
            </div>
            <div class="modal-actions cert-actions">
                <button class="btn-download-cert" (click)="printCertificate()">🖨️ Print / Save PDF</button>
                <button class="btn-cancel" (click)="showCertificateModal = false">Close</button>
            </div>
        </div>
      </div>

      <!-- Edit Profile Modal -->
      <div class="modal-overlay" *ngIf="showEditProfile" (click)="showEditProfile = false">
        <div class="modal-content" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>✏️ Edit Profile</h2>
            <button class="btn-close" (click)="showEditProfile = false">×</button>
          </div>
          
          <div class="modal-body">
            <form (ngSubmit)="saveProfile()">
              <div class="form-group">
                <label>Name</label>
                <input type="text" [(ngModel)]="editForm.name" name="name" required>
              </div>

              <div class="form-group">
                <label>Email</label>
                <input type="email" [(ngModel)]="editForm.email" name="email" required>
              </div>

              <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" [(ngModel)]="editForm.phoneNumber" name="phone">
              </div>

              <div class="form-group">
                <label>Location Coordinates</label>
                <div class="coord-inputs">
                  <input type="number" [(ngModel)]="editForm.locationLat" name="lat" placeholder="Latitude" step="any">
                  <input type="number" [(ngModel)]="editForm.locationLng" name="lng" placeholder="Longitude" step="any">
                </div>
              </div>

              <div *ngIf="editError" class="error-msg">{{ editError }}</div>
              <div *ngIf="editSuccess" class="success-msg">{{ editSuccess }}</div>

              <div class="modal-actions">
                <button type="button" class="btn-cancel" (click)="showEditProfile = false">Cancel</button>
                <button type="submit" class="btn-save" [disabled]="saving">
                  {{ saving ? 'Saving...' : 'Save Changes' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }
    .dash-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .dash-header h1 {
      margin: 0;
      font-size: 2rem;
    }
    .welcome-text {
      color: #94a3b8;
      margin: 0.25rem 0 0;
    }
    .header-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    .btn-rewards {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      padding: 0.5rem 1rem;
      border-radius: 2rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      border: none;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-rewards span {
      font-size: 1.25rem;
    }
    .btn-rewards:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(251, 191, 36, 0.4);
    }
    .btn-edit {
      background: rgba(96, 165, 250, 0.2);
      border: 1px solid #60a5fa;
      color: #60a5fa;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-edit:hover {
      background: rgba(96, 165, 250, 0.3);
    }
    .btn-logout {
      background: transparent;
      border: 1px solid #ef4444;
      color: #ef4444;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-logout:hover {
      background: #ef4444;
      color: white;
    }
    .dashboard-grid {
      display: grid;
      grid-template-columns: 350px 1fr;
      gap: 2rem;
      align-items: start;
    }
    @media (max-width: 1024px) {
      .dashboard-grid { grid-template-columns: 1fr; }
    }
    .profile-card h3 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: #60a5fa;
    }
    .profile-info {
      margin-bottom: 1.5rem;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 0.75rem 0;
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .info-row .label {
      color: #64748b;
    }
    .info-row .value {
      color: #e2e8f0;
      font-weight: 500;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .stat-box {
      text-align: center;
      padding: 1rem;
      background: rgba(255,255,255,0.03);
      border-radius: 0.75rem;
    }
    .stat-box.rewards {
      background: rgba(251, 191, 36, 0.1);
    }
    .stat-value {
      font-size: 1.75rem;
      font-weight: 700;
      color: #fff;
    }
    .stat-box.rewards .stat-value {
      color: #fbbf24;
    }
    .stat-label {
      color: #64748b;
      font-size: 0.85rem;
      margin-top: 0.25rem;
    }
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }
    .section-header h3 {
      margin: 0;
    }
    .btn-filter {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: #94a3b8;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-filter.active {
      background: rgba(96, 165, 250, 0.2);
      border-color: #60a5fa;
      color: #60a5fa;
    }
    .empty-state {
      text-align: center;
      padding: 3rem;
      color: #64748b;
      background: rgba(255,255,255,0.02);
      border-radius: 1rem;
      border: 1px dashed rgba(255,255,255,0.1);
    }
    .projects-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.5rem;
    }
    .project-card {
      padding: 1.5rem;
    }
    .project-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.75rem;
    }
    .project-header h4 {
      margin: 0;
      font-size: 1.1rem;
    }
    .reward-tag {
      background: rgba(251, 191, 36, 0.15);
      color: #fbbf24;
      padding: 0.25rem 0.5rem;
      border-radius: 0.5rem;
      font-size: 0.8rem;
      font-weight: 600;
    }
    .project-desc {
      color: #94a3b8;
      font-size: 0.9rem;
      margin-bottom: 0.75rem;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .project-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      font-size: 0.85rem;
      color: #64748b;
      margin-bottom: 0.5rem;
    }
    .project-distance {
      font-size: 0.85rem;
      color: #60a5fa;
      margin-bottom: 0.75rem;
    }
    .map-preview {
      border-radius: 0.5rem;
      overflow: hidden;
      margin-bottom: 1rem;
    }
    .btn-enroll {
      width: 100%;
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      color: white;
    }
    .btn-enroll:disabled {
      background: rgba(255,255,255,0.1);
      color: #4ade80;
      cursor: default;
    }

    /* Modal Styles */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      animation: fadeIn 0.2s;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    .modal-content {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      border-radius: 1rem;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow: hidden;
      box-shadow: 0 25px 50px rgba(0,0,0,0.5);
      animation: slideUp 0.3s;
    }
    @keyframes slideUp {
      from { transform: translateY(50px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
    }
    .btn-close {
      background: none;
      border: none;
      color: #94a3b8;
      font-size: 2rem;
      cursor: pointer;
      line-height: 1;
      transition: color 0.2s;
    }
    .btn-close:hover {
      color: #fff;
    }
    .modal-body {
      padding: 1.5rem;
      max-height: calc(80vh - 100px);
      overflow-y: auto;
    }
    .rewards-tracker-container {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      padding: 2rem;
      border-radius: 1.5rem;
      margin-bottom: 2rem;
      border: 4px solid #334155;
      box-shadow: 0 15px 35px rgba(0,0,0,0.4);
      position: relative;
      overflow: hidden;
    }
    .tracker-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 3rem;
    }
    .tracker-header h3 {
      font-size: 1.5rem;
      color: #fbbf24;
      margin: 0;
      text-shadow: 0 4px 10px rgba(251, 191, 36, 0.3);
    }
    .current-points-badge {
      background: #fbbf24;
      color: #000;
      padding: 0.5rem 1rem;
      border-radius: 2rem;
      font-weight: 800;
      transform: rotate(3deg);
      box-shadow: 4px 4px 0 #b45309;
    }
    .current-points-badge span {
      font-size: 1.25rem;
    }
    .progress-track {
      height: 20px;
      background: #334155;
      border-radius: 10px;
      position: relative;
      margin: 2rem 1rem;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.5);
    }
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, #4ade80, #22c55e);
      border-radius: 10px;
      position: relative;
      transition: width 1s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .progress-char {
      position: absolute;
      right: -15px;
      top: -30px;
      font-size: 2.5rem;
      filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));
      animation: bounce 1s infinite alternate;
    }
    @keyframes bounce {
      from { transform: translateY(0); }
      to { transform: translateY(-10px); }
    }
    .milestone-markers {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
    }
    .milestone-node {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
    }
    .milestone-icon {
      font-size: 1.5rem;
      background: #1e293b;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 3px solid #334155;
      transition: all 0.3s;
    }
    .milestone-node.reached .milestone-icon {
      border-color: #4ade80;
      background: #064e3b;
      transform: scale(1.2);
      box-shadow: 0 0 15px rgba(74, 222, 128, 0.4);
    }
    .milestone-label {
      font-size: 0.75rem;
      font-weight: 700;
      color: #64748b;
      margin-top: 2rem;
    }
    .milestone-node.reached .milestone-label {
      color: #4ade80;
    }
    .next-reward-tip {
      margin-top: 3.5rem;
      text-align: center;
      background: rgba(255,255,255,0.05);
      padding: 0.75rem;
      border-radius: 1rem;
      color: #cbd5e1;
      font-size: 0.9rem;
    }
    .next-reward-tip.success {
      background: rgba(74, 222, 128, 0.1);
      color: #4ade80;
      border: 1px dashed #4ade80;
    }
    .loading-state {
      text-align: center;
      padding: 2rem;
      color: #94a3b8;
    }
    .spinner {
      display: inline-block;
      width: 1.5rem;
      height: 1.5rem;
      border: 3px solid rgba(255,255,255,0.1);
      border-radius: 50%;
      border-top-color: #60a5fa;
      animation: spin 1s ease-in-out infinite;
      vertical-align: middle;
      margin-right: 0.5rem;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .empty-rewards {
      text-align: center;
      padding: 2rem;
      color: #64748b;
    }
    .rewards-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .reward-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1rem;
      background: rgba(255,255,255,0.03);
      border-radius: 0.75rem;
      transition: all 0.2s;
    }
    .reward-item:hover {
      background: rgba(255,255,255,0.05);
    }
    .reward-icon {
      font-size: 2rem;
    }
    .reward-details {
      flex: 1;
    }
    .reward-project {
      font-weight: 600;
      color: #e2e8f0;
      margin-bottom: 0.25rem;
    }
    .reward-desc {
      font-size: 0.8rem;
      color: #cbd5e1;
      margin-bottom: 0.25rem;
      font-style: italic;
    }
    .reward-organizer {
      font-size: 0.85rem;
      color: #94a3b8;
      margin-bottom: 0.25rem;
    }
    .reward-date {
      font-size: 0.75rem;
      color: #64748b;
    }
    .reward-points {
      font-size: 1.25rem;
      font-weight: 700;
      color: #fbbf24;
    }
    .project-image {
      height: 150px;
      margin: -1rem -1rem 1rem -1rem;
      overflow: hidden;
      border-radius: 1rem 1rem 0 0;
    }
    .project-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s;
    }
    .project-card:hover .project-image img {
      transform: scale(1.1);
    }
    .project-image.placeholder {
      background: rgba(255,255,255,0.05);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 3rem;
    }

    .reward-actions {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 1px dashed rgba(255,255,255,0.1);
    }
    .btn-evidence, .btn-view-evidence {
      background: rgba(96, 165, 250, 0.1);
      color: #60a5fa;
      border: 1px solid #60a5fa;
      padding: 0.25rem 0.5rem;
      border-radius: 0.4rem;
      font-size: 0.75rem;
      cursor: pointer;
      text-align: center;
    }
    .evidence-preview {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.5rem;
      font-size: 0.75rem;
      color: #4ade80;
    }
    .btn-download-cert {
      background: linear-gradient(135deg, #fbbf24, #d97706);
      color: #000;
      border: none;
      padding: 0.6rem 0.8rem;
      border-radius: 0.4rem;
      font-weight: 700;
      font-size: 0.8rem;
      cursor: pointer;
      transition: transform 0.2s;
    }
    .btn-download-cert:hover { transform: scale(1.02); }
    
    /* Certificate Styles */
    .certificate-frame {
      max-width: 800px;
      padding: 2rem;
      background: #fdfdfd !important;
      color: #000 !important;
    }
    .certificate-content {
      padding: 1rem;
    }
    .cert-border {
      border: 10px double #b45309;
      padding: 3rem;
      text-align: center;
      background: #fff;
    }
    .cert-header h1 {
      font-family: 'Times New Roman', serif;
      font-size: 3rem;
      margin: 1rem 0;
      color: #78350f;
    }
    .cert-logo { font-size: 4rem; }
    .recipient-name {
      font-family: 'Brush Script MT', cursive;
      font-size: 4rem;
      border-bottom: 2px solid #000;
      display: inline-block;
      min-width: 300px;
      margin: 2rem 0;
    }
    .award-text, .accomplishment-text {
      font-size: 1.25rem;
      font-style: italic;
    }
    .cert-project-name {
      font-size: 2rem;
      color: #065f46;
      margin: 1rem 0;
    }
    .cert-footer {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-top: 4rem;
    }
    .sig-line {
      width: 200px;
      border-top: 1px solid #000;
      margin-bottom: 0.5rem;
    }
    .seal {
      font-size: 5rem;
      opacity: 0.2;
    }
    .cert-actions {
      background: #1e293b;
      margin: 1rem -2rem -2rem -2rem;
      padding: 1.5rem;
    }

    .evidence-input {
      width: 100%;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: white;
      padding: 1rem;
      border-radius: 0.5rem;
      margin: 1rem 0;
      font-family: inherit;
    }
    .small-modal { max-width: 400px; }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .form-group input, .form-group textarea {
      width: 100%;
      padding: 0.75rem;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 0.5rem;
      color: white;
      font-size: 1rem;
    }
    .coord-inputs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
    }
    .error-msg {
      margin-top: 1rem;
      padding: 0.75rem;
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      border-radius: 0.5rem;
      text-align: center;
      border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .success-msg {
      margin-top: 1rem;
      padding: 0.75rem;
      background: rgba(74, 222, 128, 0.15);
      color: #4ade80;
      border-radius: 0.5rem;
      text-align: center;
    }
    .dashboard-alert {
      margin-bottom: 2rem;
      animation: slideIn 0.3s;
    }
    @keyframes slideIn {
      from { transform: translateY(-20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .modal-actions {
      display: flex;
      gap: 1rem;
      margin-top: 1.5rem;
    }
    .btn-cancel {
      flex: 1;
      padding: 0.75rem;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: #94a3b8;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-cancel:hover {
      background: rgba(255,255,255,0.1);
    }
    .btn-save {
      flex: 1;
      padding: 0.75rem;
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      border: none;
      color: white;
      border-radius: 0.5rem;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.2s;
    }
    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(96, 165, 250, 0.4);
    }
    .btn-save:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `]
})
export class MemberDashboardComponent implements OnInit {
  currentUser: User | null = null;
  projects: Project[] = [];
  searchTerm: string = '';
  enrollments: Enrollment[] = [];
  enrolledProjectIds: Set<number> = new Set();
  filterNearby = false;
  enrolling: number | null = null;

  // Rewards modal
  showRewardsModal = false;
  rewardsBreakdown: any[] = [];
  loadingRewards = false;

  milestones = [
    { points: 100, label: 'Sticker Pack', icon: '🏷️' },
    { points: 250, label: 'Eco Tote Bag', icon: '🛍️' },
    { points: 500, label: 'Eco Bottle', icon: '🧴' },
    { points: 1000, label: 'Tree Planted', icon: '🌳' }
  ];

  get rewardProgress(): number {
    const points = this.currentUser?.rewardPoints || 0;
    const maxPoints = this.milestones[this.milestones.length - 1].points;
    return Math.min((points / maxPoints) * 100, 100);
  }

  isMilestoneReached(points: number): boolean {
    return (this.currentUser?.rewardPoints || 0) >= points;
  }

  getNextMilestone() {
    const points = this.currentUser?.rewardPoints || 0;
    return this.milestones.find(m => m.points > points) || this.milestones[this.milestones.length - 1];
  }

  // Edit profile modal
  showEditProfile = false;
  editForm: any = {};
  saving = false;
  editError = '';
  editSuccess = '';

  // Evidence & Certificates
  showEvidenceModal = false;
  showCertificateModal = false;
  evidenceUrlInput = '';
  selectedReward: any = null;

  constructor(
    private api: ApiService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) { }

  ngOnInit() {
    this.api.user$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadData();
        if (this.showRewardsModal) {
          this.loadRewards();
        }
      }
    });

    // Initial check for redirection
    const initialUser = this.api.getCurrentUser();
    if (!initialUser || initialUser.role !== 'MEMBER') {
      this.router.navigate(['/member-login']);
    }
  }

  loadData() {
    this.api.getPublicProjects().subscribe(data => {
      this.ngZone.run(() => {
        this.projects = data;
        this.cdr.detectChanges();
      });
    });

    if (this.currentUser?.id) {
      this.api.getMemberEnrollments(this.currentUser.id).subscribe(data => {
        this.ngZone.run(() => {
          this.enrollments = data;
          this.enrolledProjectIds = new Set(data.map(e => Number(e.projectId)));
          console.log('Member enrollments loaded:', this.enrollments.length);
          this.cdr.detectChanges();
        });
      });
    }
  }



  loadRewards() {
    if (!this.currentUser?.id) return;

    this.loadingRewards = true;
    this.api.getMemberRewards(this.currentUser.id).subscribe({
      next: (data) => {
        this.rewardsBreakdown = data;
        this.loadingRewards = false;
      },
      error: () => {
        this.loadingRewards = false;
      }
    });
  }

  openEditProfile() {
    this.editForm = {
      name: this.currentUser?.name || '',
      email: this.currentUser?.email || '',
      phoneNumber: this.currentUser?.phoneNumber || '',
      locationLat: this.currentUser?.locationLat || 0,
      locationLng: this.currentUser?.locationLng || 0
    };
    this.editError = '';
    this.editSuccess = '';
    this.showEditProfile = true;
  }



  saveProfile() {
    if (!this.currentUser?.id) return;

    this.saving = true;
    this.editError = '';
    this.editSuccess = '';

    this.api.updateProfile(this.currentUser.id, this.editForm).subscribe({
      next: (updatedUser) => {
        this.ngZone.run(() => {
          console.log('Profile update success:', updatedUser);
          this.saving = false;
          this.showEditProfile = false;

          this.currentUser = updatedUser;
          this.showDashboardSuccess('✅ Profile updated successfully!');
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        this.editError = err.error?.error || 'Failed to update profile';
        this.saving = false;
      }
    });
  }



  get filteredProjects(): Project[] {
    let result = this.projects;

    // Filter by Search Term
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term) ||
        (p.location && p.location.toLowerCase().includes(term))
      );
    }

    // Filter by Location
    if (this.filterNearby && this.currentUser?.locationLat) {
      result = result.filter(p => this.calculateDistance(p) <= 50);
    }

    return result;
  }

  calculateDistance(project: Project): number {
    if (!this.currentUser?.locationLat || !project.latitude) return 9999;

    const R = 6371; // Earth's radius in km
    const dLat = this.toRad(project.latitude - this.currentUser.locationLat);
    const dLon = this.toRad(project.longitude - (this.currentUser.locationLng || 0));
    const lat1 = this.toRad(this.currentUser.locationLat);
    const lat2 = this.toRad(project.latitude);

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  }

  toRad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  filterByLocation() {
    this.filterNearby = !this.filterNearby;
  }

  isEnrolled(projectId: any): boolean {
    if (!projectId) return false;
    return this.enrolledProjectIds.has(Number(projectId));
  }

  enrollInProject(project: Project) {
    if (!this.currentUser?.id || !project.id || this.isEnrolled(project.id)) return;

    const projectId = Number(project.id);
    const pointsToAdd = project.rewardPoints || 0;

    // Save previous state for rollback
    const prevPoints = this.currentUser.rewardPoints || 0;
    const prevEnrollments = [...this.enrollments];
    const prevProjectIds = new Set(this.enrolledProjectIds);

    // OPTIMISTIC UPDATE: Update UI immediately
    this.ngZone.run(() => {
      this.enrolledProjectIds.add(projectId);
      this.enrollments = [...this.enrollments, {
        projectId: projectId,
        memberId: this.currentUser!.id as number,
        pointsEarned: pointsToAdd,
        enrolledAt: new Date().toISOString()
      }];

      // Update user points in the global state immediately
      this.api.updateUser({ rewardPoints: prevPoints + pointsToAdd });
      this.cdr.detectChanges();
    });

    // Backend call
    this.api.enrollInProject(projectId, this.currentUser.id).subscribe({
      next: (actualEnrollment) => {
        this.ngZone.run(() => {
          // Optionally update the mock enrollment with real DB data
          const idx = this.enrollments.findIndex(e => e.projectId === projectId);
          if (idx !== -1) {
            const newEnrollments = [...this.enrollments];
            newEnrollments[idx] = actualEnrollment;
            this.enrollments = newEnrollments;
            this.cdr.detectChanges();
          }
        });
      },
      error: (err) => {
        this.ngZone.run(() => {
          console.error('Enrollment failed:', err);
          // ROLLBACK: Revert to previous state
          this.enrolledProjectIds = prevProjectIds;
          this.enrollments = prevEnrollments;
          this.api.updateUser({ rewardPoints: prevPoints });
          this.cdr.detectChanges();

          // Brief alert to user
          alert(err.error || 'Failed to enroll. Please try again.');
        });
      }
    });
  }

  getMapUrl(project: Project): SafeResourceUrl {
    const url = `https://www.openstreetmap.org/export/embed.html?bbox=${project.longitude - 0.01},${project.latitude - 0.01},${project.longitude + 0.01},${project.latitude + 0.01}&layer=mapnik&marker=${project.latitude},${project.longitude}`;
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  // Evidence Management
  openEvidenceUpload(reward: any) {
    this.selectedReward = reward;
    this.evidenceUrlInput = '';
    this.showEvidenceModal = true;
  }

  submitEvidence() {
    if (!this.currentUser?.id || !this.selectedReward) return;

    // We need the projectId from rewardsBreakdown.
    // In our backend service, we make sure it's available.
    const projectId = this.selectedReward.projectId;

    this.api.uploadEvidence(projectId, this.currentUser.id, this.evidenceUrlInput).subscribe({
      next: () => {
        this.selectedReward.evidenceUrl = this.evidenceUrlInput;
        this.showEvidenceModal = false;
        this.showDashboardSuccess('🚀 Evidence submitted for review!');
      },
      error: (err) => alert('Failed to upload evidence')
    });
  }

  viewEvidence(url: string) {
    window.open(url, '_blank');
  }

  // Certificates
  generateCertificate(reward: any) {
    this.selectedReward = reward;
    this.showCertificateModal = true;
  }

  printCertificate() {
    const printContent = document.getElementById('certificate-print-area');
    const WindowPrt = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    if (WindowPrt && printContent) {
      WindowPrt.document.write(`
            <html>
                <head>
                    <title>Eco-Hero Certificate</title>
                    <style>
                        body { margin: 0; padding: 0; font-family: 'Times New Roman', serif; }
                        ${document.querySelector('style')?.innerHTML || ''}
                        .certificate-content { width: 100%; border: none; }
                        .cert-actions { display: none; }
                    </style>
                </head>
                <body>
                    ${printContent.innerHTML}
                    <script>
                        setTimeout(() => {
                            window.print();
                            window.close();
                        }, 500);
                    </script>
                </body>
            </html>
        `);
      WindowPrt.document.close();
    }
  }

  dashboardSuccessMsg = '';
  showDashboardSuccess(msg: string) {
    this.dashboardSuccessMsg = msg;
    setTimeout(() => this.dashboardSuccessMsg = '', 3000);
  }

  logout() {
    this.api.logout();
    this.router.navigate(['/']);
  }
}
