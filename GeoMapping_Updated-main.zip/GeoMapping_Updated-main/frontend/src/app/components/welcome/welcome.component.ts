import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-welcome',
    standalone: true,
    imports: [CommonModule, RouterModule],
    template: `
    <div class="welcome-container">
      <!-- Animated 3D Globe Background -->
      <div class="globe-container">
        <div class="globe">
          <div class="globe-inner"></div>
          <div class="orbit orbit-1"></div>
          <div class="orbit orbit-2"></div>
          <div class="orbit orbit-3"></div>
          <div class="pin pin-1"></div>
          <div class="pin pin-2"></div>
          <div class="pin pin-3"></div>
          <div class="pin pin-4"></div>
        </div>
      </div>

      <!-- Content -->
      <div class="welcome-content">
        <h1 class="title">
          <span class="gradient-text">Welcome to</span><br>
          <span class="main-title">Geo Mapping</span>
        </h1>
        <p class="subtitle">Connect with sustainable projects around you and make a difference</p>
        
        <div class="cta-buttons">
          <a routerLink="/organizer-login" class="btn-3d btn-organizer">
            <span class="btn-icon">🌱</span>
            Login as Organizer
          </a>
          <a routerLink="/member-login" class="btn-3d btn-member">
            <span class="btn-icon">🌍</span>
            Login as Member
          </a>
        </div>

        <div class="admin-link">
          <a routerLink="/admin-login">Admin Access →</a>
        </div>
      </div>

      <!-- Floating particles -->
      <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
      </div>
    </div>
  `,
    styles: [`
    .welcome-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
      background: radial-gradient(ellipse at bottom, #1B2838 0%, #090a0f 100%);
    }

    .globe-container {
      position: absolute;
      right: 10%;
      top: 50%;
      transform: translateY(-50%);
      z-index: 1;
    }

    .globe {
      width: 400px;
      height: 400px;
      border-radius: 50%;
      background: linear-gradient(135deg, #1a4a5e 0%, #0d2a35 50%, #051015 100%);
      box-shadow: 
        inset -30px -30px 60px rgba(0,0,0,0.5),
        inset 30px 30px 60px rgba(74, 222, 128, 0.1),
        0 0 100px rgba(74, 222, 128, 0.3);
      position: relative;
      animation: rotate 20s linear infinite;
    }

    .globe-inner {
      position: absolute;
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: 
        radial-gradient(circle at 30% 30%, rgba(74, 222, 128, 0.2) 0%, transparent 50%);
    }

    .orbit {
      position: absolute;
      border: 1px dashed rgba(74, 222, 128, 0.3);
      border-radius: 50%;
      animation: orbit 10s linear infinite;
    }

    .orbit-1 { width: 500px; height: 500px; top: -50px; left: -50px; animation-duration: 15s; }
    .orbit-2 { width: 550px; height: 550px; top: -75px; left: -75px; animation-duration: 20s; animation-direction: reverse; }
    .orbit-3 { width: 600px; height: 600px; top: -100px; left: -100px; animation-duration: 25s; }

    .pin {
      position: absolute;
      width: 12px;
      height: 12px;
      background: #4ade80;
      border-radius: 50%;
      box-shadow: 0 0 20px rgba(74, 222, 128, 0.8);
      animation: pulse 2s ease-in-out infinite;
    }

    .pin-1 { top: 20%; left: 30%; animation-delay: 0s; }
    .pin-2 { top: 40%; left: 70%; animation-delay: 0.5s; }
    .pin-3 { top: 60%; left: 25%; animation-delay: 1s; }
    .pin-4 { top: 75%; left: 55%; animation-delay: 1.5s; }

    @keyframes rotate {
      from { transform: rotateY(0deg); }
      to { transform: rotateY(360deg); }
    }

    @keyframes orbit {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    @keyframes pulse {
      0%, 100% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.5); opacity: 0.5; }
    }

    .welcome-content {
      position: relative;
      z-index: 10;
      text-align: left;
      padding: 2rem;
      max-width: 600px;
      margin-left: 10%;
    }

    .title {
      font-size: 1.5rem;
      font-weight: 400;
      margin-bottom: 1rem;
    }

    .gradient-text {
      background: linear-gradient(90deg, #94a3b8, #64748b);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .main-title {
      font-size: 4.5rem;
      font-weight: 800;
      background: linear-gradient(135deg, #4ade80, #22d3ee, #60a5fa);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: block;
      line-height: 1.1;
      text-shadow: 0 0 60px rgba(74, 222, 128, 0.3);
    }

    .subtitle {
      font-size: 1.25rem;
      color: #94a3b8;
      margin: 1.5rem 0 3rem;
      max-width: 400px;
    }

    .cta-buttons {
      display: flex;
      flex-direction: column;
      gap: 1rem;
      max-width: 300px;
    }

    .btn-3d {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 1rem 2rem;
      border-radius: 1rem;
      font-weight: 600;
      font-size: 1rem;
      text-decoration: none;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
    }

    .btn-organizer {
      background: linear-gradient(135deg, #4ade80, #22c55e);
      color: #000;
      box-shadow: 0 10px 30px rgba(74, 222, 128, 0.3);
    }

    .btn-member {
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      color: #fff;
      box-shadow: 0 10px 30px rgba(96, 165, 250, 0.3);
    }

    .btn-3d:hover {
      transform: translateY(-3px) scale(1.02);
    }

    .btn-icon {
      font-size: 1.5rem;
    }

    .admin-link {
      margin-top: 2rem;
    }

    .admin-link a {
      color: #64748b;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s;
    }

    .admin-link a:hover {
      color: #94a3b8;
    }

    .particles {
      position: absolute;
      width: 100%;
      height: 100%;
      overflow: hidden;
      z-index: 0;
    }

    .particle {
      position: absolute;
      width: 4px;
      height: 4px;
      background: rgba(74, 222, 128, 0.5);
      border-radius: 50%;
      animation: float 15s infinite;
    }

    .particle:nth-child(1) { left: 10%; animation-delay: 0s; animation-duration: 12s; }
    .particle:nth-child(2) { left: 30%; animation-delay: 2s; animation-duration: 14s; }
    .particle:nth-child(3) { left: 50%; animation-delay: 4s; animation-duration: 16s; }
    .particle:nth-child(4) { left: 70%; animation-delay: 6s; animation-duration: 18s; }
    .particle:nth-child(5) { left: 90%; animation-delay: 8s; animation-duration: 20s; }

    @keyframes float {
      0%, 100% { transform: translateY(100vh) scale(0); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(-100vh) scale(1); opacity: 0; }
    }

    @media (max-width: 1024px) {
      .globe-container { display: none; }
      .welcome-content { margin: 0 auto; text-align: center; }
      .cta-buttons { margin: 0 auto; }
    }
  `]
})
export class WelcomeComponent { }
