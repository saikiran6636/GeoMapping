import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-member-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="auth-container">
      <div class="auth-card card-3d">
        <div class="auth-header">
          <span class="role-badge member">🌍 Member</span>
          <h2>Login</h2>
          <p>Access projects near you</p>
        </div>
        
        <div *ngIf="error" class="error-msg">{{ error }}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label>Email or Username</label>
            <input type="text" [(ngModel)]="email" name="email" placeholder="Enter your email or username" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" [(ngModel)]="password" name="password" placeholder="Enter your password" required>
          </div>
          <button type="submit" class="btn-3d btn-member btn-full" [disabled]="loading">
            <span *ngIf="loading" class="spinner"></span>
            {{ loading ? 'Logging in...' : 'Login' }}
          </button>
        </form>

        <div class="auth-footer">
          <p>Don't have an account?</p>
          <a routerLink="/member-register" class="link-primary">Register as Member</a>
        </div>

        <a routerLink="/" class="back-link">← Back to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .auth-card {
      width: 100%;
      max-width: 420px;
    }
    .auth-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .auth-header h2 {
      margin: 1rem 0 0.5rem;
      font-size: 2rem;
    }
    .auth-header p {
      color: #94a3b8;
      font-size: 0.9rem;
    }
    .role-badge {
      display: inline-block;
      padding: 0.5rem 1rem;
      border-radius: 2rem;
      font-size: 0.9rem;
      font-weight: 600;
    }
    .role-badge.member {
      background: rgba(96, 165, 250, 0.15);
      color: #60a5fa;
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .error-msg {
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
    }
    .btn-full {
      width: 100%;
      margin-top: 0.5rem;
    }
    .btn-member {
      background: linear-gradient(135deg, #60a5fa, #3b82f6) !important;
      color: white !important;
    }
    .auth-footer {
      text-align: center;
      margin-top: 1.5rem;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    .auth-footer p {
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
    }
    .link-primary {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }
    .link-primary:hover {
      text-decoration: underline;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 1.5rem;
      color: #64748b;
      text-decoration: none;
      font-size: 0.85rem;
    }
    .spinner {
      display: inline-block;
      width: 1rem;
      height: 1rem;
      border: 2px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: #fff;
      animation: spin 1s ease-in-out infinite;
      margin-right: 0.5rem;
      vertical-align: middle;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .back-link:hover {
      color: #94a3b8;
    }
  `]
})
export class MemberLoginComponent {
  email = '';
  password = '';
  error = '';
  loading = false;

  constructor(private api: ApiService, private router: Router) { }

  onSubmit() {
    this.loading = true;
    this.error = '';

    this.api.login(this.email, this.password, 'MEMBER').subscribe({
      next: () => {
        this.router.navigate(['/member']);
      },
      error: () => {
        this.error = 'Invalid email or password';
        this.loading = false;
      }
    });
  }
}
