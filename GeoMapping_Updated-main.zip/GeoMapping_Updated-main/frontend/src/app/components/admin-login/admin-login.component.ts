import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="auth-container">
      <div class="auth-card card-3d">
        <div class="auth-header">
          <span class="role-badge admin">🔐 Admin</span>
          <h2>Admin Login</h2>
          <p>Manage projects and approvals</p>
        </div>
        
        <div *ngIf="error" class="error-msg">{{ error }}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label>Username</label>
            <input type="text" [(ngModel)]="username" name="username" placeholder="Enter admin username" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" [(ngModel)]="password" name="password" placeholder="Enter password" required>
          </div>
          <button type="submit" class="btn-3d btn-admin btn-full" [disabled]="loading">
            <span *ngIf="loading" class="spinner"></span>
            {{ loading ? 'Logging in...' : 'Login' }}
          </button>
        </form>

        <a routerLink="/" class="back-link">← Back to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .auth-card {
      width: 100%;
      max-width: 420px;
    }
    .auth-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .auth-header h2 {
      margin: 1rem 0 0.5rem;
      font-size: 2rem;
    }
    .auth-header p {
      color: #94a3b8;
      font-size: 0.9rem;
    }
    .role-badge {
      display: inline-block;
      padding: 0.5rem 1rem;
      border-radius: 2rem;
      font-size: 0.9rem;
      font-weight: 600;
    }
    .role-badge.admin {
      background: rgba(251, 191, 36, 0.15);
      color: #fbbf24;
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #cbd5e1;
    }
    .error-msg {
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 0.9rem;
    }
    .btn-full {
      width: 100%;
      margin-top: 0.5rem;
    }
    .btn-admin {
      background: linear-gradient(135deg, #fbbf24, #f59e0b) !important;
      color: #000 !important;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 2rem;
      color: #64748b;
      text-decoration: none;
      font-size: 0.85rem;
    }
    .spinner {
      display: inline-block;
      width: 1rem;
      height: 1rem;
      border: 2px solid rgba(0,0,0,0.3);
      border-radius: 50%;
      border-top-color: #000;
      animation: spin 1s ease-in-out infinite;
      margin-right: 0.5rem;
      vertical-align: middle;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .back-link:hover {
      color: #94a3b8;
    }
  `]
})
export class AdminLoginComponent {
  username = '';
  password = '';
  error = '';
  loading = false;

  constructor(private api: ApiService, private router: Router) { }

  onSubmit() {
    this.loading = true;
    this.error = '';

    this.api.login(this.username, this.password, 'ADMIN').subscribe({
      next: () => {
        this.router.navigate(['/admin']);
      },
      error: () => {
        this.error = 'Invalid credentials';
        this.loading = false;
      }
    });
  }
}
