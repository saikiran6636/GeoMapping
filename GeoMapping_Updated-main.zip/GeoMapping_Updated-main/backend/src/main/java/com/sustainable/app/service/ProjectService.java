package com.sustainable.app.service;

import com.sustainable.app.model.*;
import com.sustainable.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MemberProfileRepository memberProfileRepository;

    public Project requestProject(Project project) {
        if (projectRepository.existsByNameAndOrganizerId(project.getName(), project.getOrganizerId())) {
            throw new RuntimeException("A project with this name already exists in your account");
        }
        project.setStatus(ProjectStatus.APPROVED);
        return projectRepository.save(project);
    }

    public List<Project> getPendingProjects() {
        return projectRepository.findByStatus(ProjectStatus.PENDING);
    }

    public List<Project> getApprovedProjects() {
        return projectRepository.findByStatus(ProjectStatus.APPROVED);
    }

    public List<Project> getOrganizerProjects(Long organizerId) {
        return projectRepository.findByOrganizerId(organizerId);
    }

    public Project updateStatus(Long projectId, ProjectStatus status) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        project.setStatus(status);
        return projectRepository.save(project);
    }

    @Transactional
    public Enrollment enrollMember(Long projectId, Long memberId) {
        // Check if already enrolled
        if (enrollmentRepository.existsByMemberIdAndProjectId(memberId, projectId)) {
            throw new RuntimeException("Already enrolled in this project");
        }

        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        MemberProfile profile = memberProfileRepository.findById(memberId)
                .orElseThrow(() -> new RuntimeException("Member profile not found"));

        // Create enrollment
        Enrollment enrollment = new Enrollment();
        enrollment.setMemberId(memberId);
        enrollment.setProjectId(projectId);
        enrollment.setPointsEarned(project.getRewardPoints());

        // Update member's reward points in the separate table
        profile.setRewardPoints(profile.getRewardPoints() + project.getRewardPoints());
        memberProfileRepository.save(profile);

        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getMemberEnrollments(Long memberId) {
        return enrollmentRepository.findByMemberId(memberId);
    }

    public MemberProfile getMemberProfile(Long memberId) {
        return memberProfileRepository.findById(memberId).orElse(null);
    }

    public List<java.util.Map<String, Object>> getProjectEnrolledUsers(Long projectId) {
        List<Enrollment> enrollments = enrollmentRepository.findByProjectId(projectId);
        return enrollments.stream().map(enrollment -> {
            User user = userRepository.findById(enrollment.getMemberId()).orElse(null);
            java.util.Map<String, Object> map = new java.util.HashMap<>();
            if (user != null) {
                map.put("id", user.getId());
                map.put("name", user.getName());
                map.put("email", user.getEmail());
                map.put("phoneNumber", user.getPhoneNumber());
                map.put("enrolledAt", enrollment.getEnrolledAt());
                map.put("completionDate", enrollment.getCompletionDate());
                map.put("status", enrollment.getStatus());
                map.put("evidenceUrl", enrollment.getEvidenceUrl());
            }
            return map;
        }).collect(java.util.stream.Collectors.toList());
    }

    @Transactional
    public void completeEnrollment(Long projectId, Long memberId) {
        Enrollment enrollment = enrollmentRepository.findByMemberIdAndProjectId(memberId, projectId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollment.setStatus("COMPLETED");
        enrollment.setCompletionDate(java.time.LocalDateTime.now());
        enrollmentRepository.save(enrollment);
    }

    @Transactional
    public void uploadEvidence(Long projectId, Long memberId, String evidenceUrl) {
        Enrollment enrollment = enrollmentRepository.findByMemberIdAndProjectId(memberId, projectId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollment.setEvidenceUrl(evidenceUrl);
        enrollmentRepository.save(enrollment);
    }

    @Transactional
    public Project updateProject(Long projectId, Project updatedProject) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        // Update fields
        project.setName(updatedProject.getName());
        project.setDescription(updatedProject.getDescription());
        project.setLocation(updatedProject.getLocation());
        project.setLatitude(updatedProject.getLatitude());
        project.setLongitude(updatedProject.getLongitude());
        project.setRewardPoints(updatedProject.getRewardPoints());
        project.setStartDate(updatedProject.getStartDate());
        project.setEndDate(updatedProject.getEndDate());
        project.setImageUrl(updatedProject.getImageUrl());

        return projectRepository.save(project);
    }

    @Transactional
    public void deleteProject(Long projectId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        // Delete all enrollments first
        enrollmentRepository.deleteByProjectId(projectId);
        enrollmentRepository.flush();

        // Delete the project
        projectRepository.delete(project);
        projectRepository.flush();
    }

    public List<java.util.Map<String, Object>> getMemberRewardsBreakdown(Long memberId) {
        List<Enrollment> enrollments = enrollmentRepository.findByMemberId(memberId);
        return enrollments.stream().map(enrollment -> {
            Project project = projectRepository.findById(enrollment.getProjectId()).orElse(null);
            java.util.Map<String, Object> map = new java.util.HashMap<>();
            if (project != null) {
                map.put("projectId", project.getId());
                map.put("projectName", project.getName());
                map.put("projectDescription", project.getDescription());
                map.put("pointsEarned", enrollment.getPointsEarned());
                map.put("enrolledAt", enrollment.getEnrolledAt());
                map.put("status", enrollment.getStatus());
                map.put("evidenceUrl", enrollment.getEvidenceUrl());
                map.put("organizerName", project.getOrganizerName());
            }
            return map;
        }).collect(java.util.stream.Collectors.toList());
    }
}
