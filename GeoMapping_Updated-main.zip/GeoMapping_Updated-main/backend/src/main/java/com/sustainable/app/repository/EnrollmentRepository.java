package com.sustainable.app.repository;

import com.sustainable.app.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByMemberId(Long memberId);

    List<Enrollment> findByProjectId(Long projectId);

    java.util.Optional<Enrollment> findByMemberIdAndProjectId(Long memberId, Long projectId);

    boolean existsByMemberIdAndProjectId(Long memberId, Long projectId);

    @Modifying
    @Query("DELETE FROM Enrollment e WHERE e.projectId = :projectId")
    void deleteByProjectId(@Param("projectId") Long projectId);
}
