package com.sustainable.app.repository;

import com.sustainable.app.model.Project;
import com.sustainable.app.model.ProjectStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByStatus(ProjectStatus status);

    List<Project> findByOrganizerId(Long organizerId);

    boolean existsByNameAndOrganizerId(String name, Long organizerId);
}
