package com.sustainable.app.controller;

import com.sustainable.app.model.*;
import com.sustainable.app.dto.UserDTO;
import com.sustainable.app.service.AuthService;
import com.sustainable.app.service.ProjectService;
import com.sustainable.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProjectService projectService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, Object> payload) {
        User user = new User();
        user.setName((String) payload.get("name"));
        user.setEmail((String) payload.get("email"));
        user.setPhoneNumber((String) payload.get("phoneNumber"));
        user.setPassword((String) payload.get("password"));
        user.setRole(Role.valueOf((String) payload.get("role")));

        Double lat = payload.get("locationLat") != null ? Double.valueOf(payload.get("locationLat").toString()) : null;
        Double lng = payload.get("locationLng") != null ? Double.valueOf(payload.get("locationLng").toString()) : null;

        try {
            User registered = authService.register(user, lat, lng);
            return ResponseEntity
                    .ok(Map.of("success", true, "message", "Registration successful", "userId", registered.getId()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> creds) {
        String email = creds.get("email");
        String password = creds.get("password");
        String roleStr = creds.get("role");

        if (roleStr == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Role is required"));
        }

        Role role = Role.valueOf(roleStr);
        User user = authService.login(email, password, role);

        if (user != null) {
            UserDTO dto = new UserDTO(user);

            // Fetch profile for member to populate extra fields
            if (user.getRole() == Role.MEMBER) {
                MemberProfile profile = projectService.getMemberProfile(user.getId());
                if (profile != null) {
                    dto.setLocationLat(profile.getLocationLat());
                    dto.setLocationLng(profile.getLocationLng());
                    dto.setRewardPoints(profile.getRewardPoints());
                } else {
                    dto.setLocationLat(0.0);
                    dto.setLocationLng(0.0);
                    dto.setRewardPoints(0);
                }
            } else if (user.getRole() == Role.ORGANIZER) {
                // Organizer doesn't need extra profile fields for now, but could add later
            }

            return ResponseEntity.ok(dto);
        }
        return ResponseEntity.status(401).body(Map.of("error", "Invalid credentials"));
    }

    @PostMapping("/check-email")
    public ResponseEntity<?> checkEmail(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String roleStr = body.get("role");
        Role role = Role.valueOf(roleStr);
        boolean exists = authService.checkEmailExists(email, role);
        return ResponseEntity.ok(Map.of("exists", exists));
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @PutMapping("/profile/{userId}")
    public ResponseEntity<?> updateProfile(@PathVariable Long userId, @RequestBody Map<String, Object> payload) {
        try {
            User updatedUser = authService.updateProfile(userId, payload);
            UserDTO dto = new UserDTO(updatedUser);

            // Fetch updated profile for member
            if (updatedUser.getRole() == Role.MEMBER) {
                MemberProfile profile = projectService.getMemberProfile(updatedUser.getId());
                if (profile != null) {
                    dto.setLocationLat(profile.getLocationLat());
                    dto.setLocationLng(profile.getLocationLng());
                    dto.setRewardPoints(profile.getRewardPoints());
                }
            }

            return ResponseEntity.ok(dto);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
