package com.sustainable.app.repository;

import com.sustainable.app.model.OrganizerProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrganizerProfileRepository extends JpaRepository<OrganizerProfile, Long> {
}
