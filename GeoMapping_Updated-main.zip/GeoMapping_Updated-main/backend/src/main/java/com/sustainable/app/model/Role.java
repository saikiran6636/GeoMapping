package com.sustainable.app.model;

public enum Role {
    ADMIN,
    ORGANIZER,
    MEMBER
}
