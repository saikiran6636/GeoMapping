package com.sustainable.app.service;

import com.sustainable.app.model.*;
import com.sustainable.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MemberProfileRepository memberProfileRepository;

    @Autowired
    private OrganizerProfileRepository organizerProfileRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public User register(User user, Double lat, Double lng) {
        // Check if email already exists for this role
        Optional<User> existing = userRepository.findByEmailAndRole(user.getEmail(), user.getRole());
        if (existing.isPresent()) {
            throw new RuntimeException("Email already registered for this role");
        }

        if (user.getUsername() == null || user.getUsername().isBlank()) {
            user.setUsername(user.getEmail());
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        User savedUser = userRepository.save(user);

        // Store in separate table based on role
        if (savedUser.getRole() == Role.MEMBER) {
            MemberProfile member = new MemberProfile(savedUser);
            member.setLocationLat(lat);
            member.setLocationLng(lng);
            member.setRewardPoints(0);
            memberProfileRepository.save(member);
        } else if (savedUser.getRole() == Role.ORGANIZER) {
            OrganizerProfile organizer = new OrganizerProfile(savedUser);
            organizerProfileRepository.save(organizer);
        }

        return savedUser;
    }

    public User login(String email, String password, Role role) {
        Optional<User> userOpt;
        if (role == Role.ADMIN) {
            userOpt = userRepository.findByUsername(email);
        } else {
            // Try by email first
            userOpt = userRepository.findByEmailAndRole(email, role);
            // If not found, try by username
            if (userOpt.isEmpty()) {
                userOpt = userRepository.findByUsername(email)
                        .filter(u -> u.getRole() == role);
            }
        }

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            boolean matches = passwordEncoder.matches(password, user.getPassword());

            if (matches) {
                return user;
            }
        }
        return null;
    }

    public boolean checkEmailExists(String email, Role role) {
        return userRepository.findByEmailAndRole(email, role).isPresent();
    }

    @Transactional
    public User updateProfile(Long userId, java.util.Map<String, Object> payload) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Update basic user fields
        if (payload.containsKey("name")) {
            user.setName((String) payload.get("name"));
        }
        if (payload.containsKey("email")) {
            user.setEmail((String) payload.get("email"));
        }
        if (payload.containsKey("phoneNumber")) {
            user.setPhoneNumber((String) payload.get("phoneNumber"));
        }

        User savedUser = userRepository.save(user);

        // Update role-specific profile
        if (user.getRole() == Role.MEMBER) {
            MemberProfile profile = memberProfileRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("Member profile not found"));

            if (payload.containsKey("locationLat")) {
                profile.setLocationLat(Double.valueOf(payload.get("locationLat").toString()));
            }
            if (payload.containsKey("locationLng")) {
                profile.setLocationLng(Double.valueOf(payload.get("locationLng").toString()));
            }

            memberProfileRepository.save(profile);
        }
        // Note: Organizer profile has no additional fields to update currently

        return savedUser;
    }
}
