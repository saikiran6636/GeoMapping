package com.sustainable.app.controller;

import com.sustainable.app.model.*;
import com.sustainable.app.service.ProjectService;
import com.sustainable.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/request")
    public ResponseEntity<Project> requestProject(@RequestBody Project project) {
        System.out.println(
                "Received project request: " + project.getName() + " from organizer: " + project.getOrganizerId());
        Project saved = projectService.requestProject(project);
        System.out.println("Project saved with ID: " + saved.getId() + " and status: " + saved.getStatus());
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<Project>> getPendingProjects() {
        return ResponseEntity.ok(projectService.getPendingProjects());
    }

    @GetMapping("/public")
    public ResponseEntity<List<Project>> getApprovedProjects() {
        List<Project> approved = projectService.getApprovedProjects();
        System.out.println("Returning " + approved.size() + " public approved projects");
        return ResponseEntity.ok(approved);
    }

    @GetMapping("/organizer/{id}")
    public ResponseEntity<List<Project>> getOrganizerProjects(@PathVariable Long id) {
        List<Project> projects = projectService.getOrganizerProjects(id);
        System.out.println("Returning " + projects.size() + " projects for organizer: " + id);
        return ResponseEntity.ok(projects);
    }

    @PostMapping("/{id}/status")
    public ResponseEntity<Project> updateStatus(@PathVariable Long id, @RequestBody Map<String, String> statusMap) {
        ProjectStatus status = ProjectStatus.valueOf(statusMap.get("status"));
        return ResponseEntity.ok(projectService.updateStatus(id, status));
    }

    @PostMapping("/{projectId}/enroll/{memberId}")
    public ResponseEntity<?> enrollInProject(@PathVariable Long projectId, @PathVariable Long memberId) {
        try {
            Enrollment enrollment = projectService.enrollMember(projectId, memberId);
            return ResponseEntity.ok(enrollment);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/enrollments/{memberId}")
    public ResponseEntity<List<Enrollment>> getMemberEnrollments(@PathVariable Long memberId) {
        return ResponseEntity.ok(projectService.getMemberEnrollments(memberId));
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<?> getMemberDetails(@PathVariable Long memberId) {
        MemberProfile profile = projectService.getMemberProfile(memberId);
        User user = userRepository.findById(memberId).orElse(null);

        java.util.Map<String, Object> response = new java.util.HashMap<>();
        response.put("user", user);
        response.put("profile", profile);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{projectId}/members")
    public ResponseEntity<List<Map<String, Object>>> getProjectMembers(@PathVariable Long projectId) {
        return ResponseEntity.ok(projectService.getProjectEnrolledUsers(projectId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Project> updateProject(@PathVariable Long id, @RequestBody Project project) {
        try {
            Project updated = projectService.updateProject(id, project);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProject(@PathVariable Long id) {
        try {
            projectService.deleteProject(id);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/rewards/{memberId}")
    public ResponseEntity<List<Map<String, Object>>> getMemberRewards(@PathVariable Long memberId) {
        return ResponseEntity.ok(projectService.getMemberRewardsBreakdown(memberId));
    }

    @PostMapping("/{projectId}/complete/{memberId}")
    public ResponseEntity<?> completeEnrollment(@PathVariable Long projectId, @PathVariable Long memberId) {
        try {
            projectService.completeEnrollment(projectId, memberId);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{projectId}/evidence/{memberId}")
    public ResponseEntity<?> uploadEvidence(@PathVariable Long projectId, @PathVariable Long memberId,
            @RequestBody Map<String, String> body) {
        try {
            projectService.uploadEvidence(projectId, memberId, body.get("evidenceUrl"));
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
