package com.sustainable.app.repository;

import com.sustainable.app.model.User;
import com.sustainable.app.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    Optional<User> findByEmailAndRole(String email, Role role);

    Optional<User> findByPhoneNumber(String phoneNumber);
}
