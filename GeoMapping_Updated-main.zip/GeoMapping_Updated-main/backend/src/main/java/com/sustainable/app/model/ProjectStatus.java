package com.sustainable.app.model;

public enum ProjectStatus {
    PENDING,
    APPROVED,
    REJECTED
}
