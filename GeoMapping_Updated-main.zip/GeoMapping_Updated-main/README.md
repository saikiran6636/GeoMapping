# Sustainable Project App

## Backend (Spring Boot)
1. Navigate to `backend` folder.
2. Ensure you have Java 17+ installed.
3. You can run the application using your IDE (Run `SustainableApplication.java`) or using Maven:
   ```bash
   mvn spring-boot:run
   ```
4. It runs on `http://localhost:8080`.
5. H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:file:./data/demo`, User: `sa`, Pass: `password`).
6. **Admin Credentials**: Username: `admin`, Password: `admin123`.

## Frontend (Angular)
1. Navigate to `frontend` folder.
2. Install dependencies (if needed):
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm start
   ```
4. Access the app at `http://localhost:4200`.

## Features
- **Admin**: Approve/Reject projects.
- **Organizer**: Add projects (lat/long, description).
- **Member**: View approved projects, contribute.
